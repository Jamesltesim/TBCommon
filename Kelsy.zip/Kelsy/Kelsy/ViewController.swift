//
//  ViewController.swift
//  Kelsy
//
//  Created by Toby on 2017/12/16.
//  Copyright © 2017年 Toby. All rights reserved.
//

import UIKit
import ISTimeline

class ViewController: UIViewController {
    
    @IBOutlet weak var timeline: ISTimeline!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let black = UIColor.black
        
        
        let green = UIColor.init(red: 76/255, green: 175/255, blue: 80/255, alpha: 1)
        
        let touchAction = { (point:ISPoint) in
            print("point \(point.title)")
            
            
            let vc = UIViewController()
            vc.view.backgroundColor = UIColor.white
            //push方式
            self.navigationController!.pushViewController(vc, animated:true)
            
        }
        
        let myPoints = [
            ISPoint(title: "2017.10.20 06:46 AM", description: "      Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam. \n\n       but the very next day you gave it away this year to save me from tears ill give it to someone special last christmas i gave you my heart but hte very next day you gave it away this year to save me from tears,", pointColor: black, lineColor: black, touchUpInside: touchAction, fill: false),
            
            ISPoint(title: "07:00 AM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr.", pointColor: black, lineColor: black, touchUpInside: touchAction, fill: false),
            
            ISPoint(title: "07:30 AM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam.", pointColor: black, lineColor: black, touchUpInside: touchAction, fill: false),
            
            ISPoint(title: "08:00 AM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt.", pointColor: green, lineColor: green, touchUpInside: touchAction, fill: true),
            
            ISPoint(title: "11:30 AM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam.", pointColor: green, lineColor: green, touchUpInside: touchAction, fill: true),
            
            ISPoint(title: "02:30 PM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam.", touchUpInside: touchAction),
            
            ISPoint(title: "05:00 PM", description: "Lorem ipsum dolor sit amet.", touchUpInside: touchAction),
            
            ISPoint(title: "08:15 PM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam.", touchUpInside: touchAction),
            
            ISPoint(title: "11:45 PM", description: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam.", touchUpInside: touchAction)
        ]
        
        timeline.contentInset = UIEdgeInsetsMake(20.0, 20.0, 20.0, 20.0)
        timeline.points = myPoints
    }
}

