//
//  TTDrawChart.m
//  TETT
//
//  Created by Toby on 2018/1/27.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "TTDrawChart.h"

@interface TTDrawChart()

//背景线颜色
@property (nonatomic,strong) UIColor *lineColor;

@end

@implementation TTDrawChart

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.lineColor = [UIColor grayColor];
    }
    return self;
}
- (void)drawRect:(CGRect)rect {
    
    //An opaque type that represents a Quartz 2D drawing environment.
    //一个不透明类型的Quartz 2D绘画环境,相当于一个画布,你可以在上面任意绘画
    
    //边距
    CGFloat pace = 20.0;
    //坐标系 O 点坐标
    CGPoint o = CGPointMake(25, rect.size.height-30);
    
    //x y 轴长度
    CGFloat x = rect.size.width-o.x*2;
    CGFloat y = rect.size.height-40;
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    //绘制坐标系
    CGContextSetRGBStrokeColor(context, 0.8, 0.8, 0.8, 1);//线条颜色
    CGContextMoveToPoint(context, o.x, pace);
    CGContextAddLineToPoint(context, o.x,o.y);
    CGContextAddLineToPoint(context, o.x+x,o.y);
    CGContextStrokePath(context);
    
    //绘制纵轴底线
    for(int i = 0;i<self.verticalArray.count;i++){
        if(i== 0){
            continue;
        }
        CGFloat space = x/(self.verticalArray.count-1);
        CGContextSetRGBStrokeColor(context, 0.4, 0.4, 0.4, 1);//线条颜色
        CGContextMoveToPoint(context, o.x+i*space, pace);
        CGContextAddLineToPoint(context, o.x+i*space,o.y);
        CGContextStrokePath(context);
    }
    
    //横轴标注
    for(int i = 0;i<self.verticalArray.count;i++){
        CGFloat space = x/(self.verticalArray.count-1);
        
        CGContextSetLineWidth(context, 1.0);
        CGContextSetRGBFillColor (context, 0.75, 0.75, 0.75, 1);
        UIFont  *font = [UIFont boldSystemFontOfSize:11.0];
        [[NSString stringWithFormat:@"%ld:00",(int)24/(self.verticalArray.count-1)*i ] drawInRect:CGRectMake(o.x+i*space-15, o.y, space, 20) withFont:font];
        
    }
    
  
    
    
    //绘制横轴底线
    for(int i=1;i<[self countHLines:y];i++){
     
    
        CGFloat space = y/([self countHLines:y]);
        CGContextSetRGBStrokeColor(context, 0.4, 0.4, 0.4, 1);//线条颜色
        CGContextMoveToPoint(context, o.x, o.y-i*space);
        CGContextAddLineToPoint(context, o.x+x,o.y-i*space);
        CGContextStrokePath(context);
        
    }
    
        for(int i=1;i<[self countHLines:y];i++){
           CGFloat space = y/([self countHLines:y]);
    
            CGContextSetLineWidth(context, 1.0);
            CGContextSetRGBFillColor (context, 0.75, 0.75, 0.75, 1);
            UIFont  *font = [UIFont boldSystemFontOfSize:11.0];
            
            int lines =floorf([self countHLines:y]);
            NSInteger maxNum =[[self maxNumber:self.dataArray]integerValue];
            
            NSInteger num = ((maxNum/lines)/10+1)*10;
           
            [[NSString stringWithFormat:@"%ld",num*i] drawInRect:CGRectMake(o.x-20, o.y-space*i-8, space, 20) withFont:font];
        }
}

//根据y轴长度 得到水平线的个数
//默认水平线间隔为25
- (CGFloat)countHLines:(CGFloat)height{
    
    int defaultSpace = 20;
    return (height/defaultSpace)-1;
    
}

- (NSNumber *)maxNumber:(NSArray<NSNumber *> *)nums{
    NSNumber *target = nums[0];
    
    for(NSNumber *num in nums){
        if([target compare:num] == kCFCompareLessThan){
            target = num;
        }
    }
    
    return target;
}

/*
 Only override drawRect: if you perform custom drawing.
 An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 Drawing code
 }
 */

@end

