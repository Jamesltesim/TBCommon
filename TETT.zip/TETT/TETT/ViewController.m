//
//  ViewController.m
//  TETT
//
//  Created by Toby on 2018/1/27.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "ViewController.h"
#import "TTHeaderView.h"
#import "MerchantInfoTableViewCell.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) NSArray *dataArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.dataArray = @[@[@"today_order",@"to_new_ord",@"to_yijie_ord",@"to_dlivry_ord",@"to_finish_ord",@"总 order"],
                       @[@"laoban_name",@"phone",@"wechat",@"address",@"suoshu_shangquan"],
                       @[@"",@"",@"",@"",@"",@"",@"",@""]];
    
    UITableView *tab = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    tab.delegate = self;
    tab.dataSource = self;
//    tab.tableHeaderView = [[TTHeaderView alloc] init];
    [self.view addSubview:tab];
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray *array = self.dataArray[section];
    return array.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    MerchantInfoTableViewCell *cell = [[[NSBundle mainBundle] loadNibNamed:@"MerchantInfoTableViewCell" owner:nil options:nil]lastObject];
   
    NSArray *array = self.dataArray[indexPath.section];
    cell.name.text = array[indexPath.row];
    cell.info.text = @"1";
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
