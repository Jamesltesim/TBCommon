//
//  TTHeaderView.m
//  TETT
//
//  Created by Toby on 2018/1/27.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "TTHeaderView.h"
#import "TTDrawChart.h"

@implementation TTHeaderView

- (instancetype)init{
    if(self = [super init]){
        
        CGFloat width = [[UIScreen mainScreen]bounds].size.width;
        self.frame = CGRectMake(0, 0, width, 240);
        self.backgroundColor = [UIColor grayColor];
        
        TTDrawChart *chart = [[TTDrawChart alloc]initWithFrame:CGRectMake(0, 0, width, self.frame.size.height-50)];
        
        chart.verticalArray = @[@"00:00",@"04:00",@"08:00",@"12:00",@"16:00",@"20:00",@"24:00"];
        
        chart.dataArray = @[@(120),@(190),@(70),@(75),@(100),@(12)];
        [self addSubview:chart];
    }
    return self;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
