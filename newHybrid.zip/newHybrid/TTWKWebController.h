//
//  TTWKWebController.h
//  WKTest01
//
//  Created by Toby on 2018/1/4.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTJSBridge.h"

/////////////原项目中 ViewController copy/////////////////////////////////
#import "TabbarController.h"
#import "ViewController.h"
//@protocol NavgationViewDelegate;
//
//@interface NavgationView : UIView
//@property (nonatomic, strong) UIImageView           *bgImgView;
//@property (nonatomic, strong) UILabel               *titleLabel;
//@property (nonatomic, strong) UIButton              *btnLeft;
//@property (nonatomic, weak) id<NavgationViewDelegate> delegate;
//@end
/////////////原项目中 ViewController copy/////////////////////////////////




@interface TTWKWebController : UIViewController<AppInvokeDelegate>


@property (nonatomic,strong) NSString *startPage;

@property (nonatomic,strong) TTJSBridge *JSBridge;

- (void)reloadWkWebView;

//@property (nonatomic,weak) id<AppInvokeDelegate>delegate;



/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////

@property (nonatomic, assign) BOOL                  hideBackBtn;
@property (nonatomic, assign) BOOL                  hideNavgation;
@property (nonatomic, strong) UIColor               *statusBarBackgroundColor;

@property (nonatomic, strong, readonly)TabbarController *tabbarController;
@property (nonatomic, strong)   NavgationView           *navgationView;
@end






//@protocol NavgationViewDelegate <NSObject>
//
//- (void)NavgationView:(NavgationView *)view TapGestureRecognizerAction:(NSObject *)sender;
//
//@end

/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////
