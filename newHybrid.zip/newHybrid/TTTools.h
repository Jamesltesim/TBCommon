//
//  TTTools.h
//  WKTest01
//
//  Created by Toby on 2018/1/8.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TTTools : NSObject

//json -> dictionary
+ (NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString;


//得到 沙盒路径
+(NSString *)documentPath;


//根据js传过来的 url ，转换成 zip下的本地html路径
+ (NSString *)getLocalUrl:(NSString *)url;
@end
