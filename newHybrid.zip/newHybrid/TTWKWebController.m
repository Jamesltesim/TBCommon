//
//  TTWKWebController.m
//  WKTest01
//
//  Created by Toby on 2018/1/4.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "TTWKWebController.h"
#import <WebKit/WebKit.h>
#import "WKDelegateController.h"
#import "CacheManager.h"
#import "TTTools.h"


#define WEBVIEW_LOADFINISHTOCALLJS_STRING @"JSCallback({\"data\":\"1\",\"requestId\":\"0\",\"method\":\"loadFinish\"})"
@interface TTWKWebController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler,
UIWebViewDelegate,
WKDelegate>



@property (nonatomic,strong) WKWebView *wkWebView;
@property (nonatomic,strong) WKUserContentController* userContentController;

@end

@implementation TTWKWebController

#pragma mark- life cycle

- (void)reloadWkWebView{
    
    
    [self.wkWebView reload];
}

//
//[self.wkWebView evaluateJavaScript:@"navigator.userAgent" completionHandler:^(id result, NSError *error) {
//
//
//    //
//    NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:newUserAgaent, @"UserAgent", nil];
//    [[NSUserDefaults standardUserDefaults] registerDefaults:dictionary];
//    //        [[NSUserDefaults standardUserDefaults] synchronize];
//    //        在网上找到的没有下面这句话，结果只是更改了本地的UserAgent，没修改网页的，导致一直有问题，好低级的错误，这个函数是9.0之后才出现的，在这之前，把这段代码放在WKWebView的alloc之前才会有效
//    //        [self.wkWebView setCustomUserAgent:newUserAgaent];
//
//    //        echo(@"%@",[[NSUserDefaults standardUserDefaults] stringForKey:@"UserAgent"]);
//
//
//    NSLog(@"UserAgent error:%@",error);
//}];

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    /////////////原项目中 ViewController copy/////////////////////////////////
//    self.automaticallyAdjustsScrollViewInsets = NO;
//    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
//    NSArray* tmp = self.navigationController.viewControllers;
//    [self setHideBackBtn:tmp.count > 1 ? NO : YES];
//
//    [self.view addSubview:self.navgationView];
    
    /////////////原项目中 ViewController copy/////////////////////////////////
    
    
    self.startPage = [TTTools getLocalUrl:self.startPage];
    
    [self.view addSubview:self.wkWebView];
    
    
    self.JSBridge = [TTJSBridge instanceWithWKWebView:self.wkWebView delegate:self];
//    NSLog(@"viewDidLoad:时间戳:%f",[[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970]);
    
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self.JSBridge evaluateJavaScriptWithParamString:WEBVIEW_LOADFINISHTOCALLJS_STRING completionHandler:^(id _Nullable task, NSError * _Nullable error) {
        NSLog(@"Base viewWillAppear  ->  执行 loadfinish call JS :%@",error);
    }];
    
    /////////////原项目中 ViewController copy/////////////////////////////////
//    [self setStatusBarBackgroundColor:[UIColor clearColor]];
    /////////////原项目中 ViewController copy/////////////////////////////////
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- appInvokeDelegate



#pragma mark- set get
- (WKWebView *)wkWebView{
    if(!_wkWebView){
        //配置环境
        WKWebViewConfiguration * configuration = [[WKWebViewConfiguration alloc]init];
        _userContentController =[[WKUserContentController alloc]init];
        configuration.userContentController = _userContentController;
        
        //注册方法
        WKDelegateController * delegateController = [[WKDelegateController alloc]init];
        delegateController.delegate = self;
        
        [_userContentController addScriptMessageHandler:self  name:@"appInvoke"];
        
        
        CGFloat  width = [[UIScreen mainScreen] bounds].size.width;
        CGFloat  height = [[UIScreen mainScreen] bounds].size.height;
        _wkWebView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:configuration];
//        _wkWebView = [[WKWebView alloc] initWithFrame:CGRectMake(0, 64, width, height-64) configuration:configuration];
        _wkWebView.UIDelegate = self;
        _wkWebView.navigationDelegate = self;
        
        //    [_wkWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"https://www.baidu.com"]]];
        
        
        
//        NSURL *filePath = [[NSBundle mainBundle] URLForResource:(self.startPage != nil?self.startPage:@"html/index_wk.html") withExtension:nil];
//        NSURLRequest *request = [NSURLRequest requestWithURL:filePath];
        
        NSArray *array = [self.startPage componentsSeparatedByString:@"/"];
        
        NSMutableString *url = [[NSMutableString alloc]initWithCapacity:0];
        
        NSMutableArray *marray = [[NSMutableArray alloc]initWithArray:array];
        [marray removeLastObject];
        [marray removeLastObject];
        [marray removeLastObject];
        
        [url appendString:@"file:///"];
        for(NSString *str in marray){
            [url appendString:str];
            [url appendString:@"/"];
        }
        
        NSLog(@"startPage:%@",self.startPage);
        
        [_wkWebView loadFileURL:[NSURL fileURLWithPath:self.startPage] allowingReadAccessToURL:[NSURL fileURLWithPath:url]];
        
//        NSURL *filePath = [[NSBundle mainBundle] URLForResource:@"app-recompress/__html/common/login.htm" withExtension:nil];
//        NSURLRequest *request = [NSURLRequest requestWithURL:filePath];
//        [_wkWebView loadRequest:request];
    }
    return _wkWebView;
}

//- (void)loadFinishCallJS {
//    NSMutableDictionary *dic = @{}.mutableCopy;
//    dic[@"requestId"] = @"0";
//    dic[@"method"] = @"loadFinish";
//    dic[@"data"] = @"1";
//    [self nativeCallJSFunctionName:@"JSCallback" arguments:dic];
//
//}
//
//- (id)nativeCallJSFunctionName:(NSString *)functionName arguments:(NSDictionary *)arguments{
//    NSDictionary *dic = [NSDictionary dictionaryWithDictionary:arguments];
//    NSLog(@"回掉的参数 = %@",dic);
//    arguments = arguments?arguments:@{};
//    [self stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"%@(%@)",functionName,[arguments JSONString]]];
//    return nil;;
//}

#pragma mark - WKScriptMessageHandler
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message{
    [self.JSBridge getJSMessage:message];
    
}

#pragma mark- WKUIDelegate来追踪加载过程
// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation{
    NSLog(@"%@",NSStringFromSelector(_cmd));

    
//    NSLog(@"时间戳:%f",[[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970]);
//    NSLog(@"wkWebView-> url : %@",webView.URL.absoluteString);
}
// 当内容开始返回时调用
- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation{
    NSLog(@"%@",NSStringFromSelector(_cmd));
//    NSLog(@"时间戳:%f",[[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970]);
}
// 页面加载完成之后调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation{
    NSLog(@"%@",NSStringFromSelector(_cmd));
//    NSLog(@"时间戳:%f",[[NSDate dateWithTimeIntervalSinceNow:0] timeIntervalSince1970]);

    
    
    [webView evaluateJavaScript:WEBVIEW_LOADFINISHTOCALLJS_STRING completionHandler:^(id _Nullable task, NSError * _Nullable error) {
        NSLog(@"didFinishNavigation:%@",error);
    }];
}
// 页面加载失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation{
    NSLog(@"%@",NSStringFromSelector(_cmd));
   
}


#pragma mark- WKNavigtionDelegate来进行页面跳转
// 接收到服务器跳转请求之后再执行
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation{
    NSLog(@"%@",NSStringFromSelector(_cmd));
 
}
// 在收到响应后，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler{
    NSLog(@"%@",NSStringFromSelector(_cmd));

    decisionHandler(WKNavigationActionPolicyAllow);
    
}
// 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler{
    NSLog(@"%@",NSStringFromSelector(_cmd));
    decisionHandler(WKNavigationActionPolicyAllow);
}


//1.创建一个新的WebVeiw
#pragma mark - WKUIDelegate
// 创建一个新的WebView
- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures{
   
    return [[WKWebView alloc]init];
}
// 输入框
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(nullable NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * __nullable result))completionHandler{
    NSLog(@"%@",NSStringFromSelector(_cmd));

    completionHandler(@"http");
}
// 确认框
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL result))completionHandler{

    completionHandler(YES);
}
// 警告框
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler{
    NSLog(@"%@",message);

    completionHandler();
}





/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */









/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////
/////////////原项目中 ViewController copy/////////////////////////////////

- (BOOL)prefersStatusBarHidden{
    return NO;
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}


- (BOOL)shouldAutorotate{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations{
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation{
    return UIInterfaceOrientationPortrait;
}

#pragma mark - configure
- (void)leftButtonAction:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - public
//- (void)showLoadingText:(NSString *)text{
//    dispatch_main_async_safe(^{
//        [MBProgressHUD showMessag:text toView:self.view];
//    });
//}
//- (void)showLoading{
//    dispatch_main_async_safe(^{
//        [MBProgressHUD showLoadingSingleInView:self.view animated:YES];
//    })
//}
//- (void)hideLoading{
//    dispatch_main_async_safe(^{
//        [MBProgressHUD hideHUDForView:self.view animated:NO];
//    })
//}
//
//- (void)showError:(NSString *)error{
//    dispatch_main_async_safe(^{
//        [MBProgressHUD showError:error toView:self.view];
//    })
//}
//
//- (void)showSuccess:(NSString *)success{
//    dispatch_main_async_safe(^{
//        [MBProgressHUD showSuccess:success toView:self.view];
//    })
//}

//- (void)NavgationView:(NavgationView *)view TapGestureRecognizerAction:(NSObject *)sender {
//    NSString *systemEnv = @"本地";
//    if (APP_API_ENVIRONMENT_MACRO == 1) {
//        systemEnv = @"运测";
//    }
//
//    else if (APP_API_ENVIRONMENT_MACRO == 2) {
//        systemEnv = @"运营";
//    }
//
//    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil];
//    NSString *message = [NSString stringWithFormat:@"运行环境：%@\n版本号：%@", systemEnv, app_version];
//    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"系统信息" message:message preferredStyle:UIAlertControllerStyleAlert];
//    [controller addAction:action];
//    [self presentViewController:controller animated:YES completion:nil];
//}

#pragma mark setter
//设置状态栏颜色
- (void)setStatusBarBackgroundColor:(UIColor *)statusBarBackgroundColor{
    UIView *statusBar = [[[UIApplication sharedApplication] valueForKey:@"statusBarWindow"] valueForKey:@"statusBar"];
    if ([statusBar respondsToSelector:@selector(setBackgroundColor:)]) {
        statusBar.backgroundColor = statusBarBackgroundColor;
    }
}

- (void)setHideNavgation:(BOOL)hideNavgation{
    _hideNavgation = hideNavgation;
    self.navgationView.hidden = hideNavgation;
    //    if (hideNavgation) {
    //        [self.navgationView mas_updateConstraints:^(MASConstraintMaker *make) {
    //            make.height.equalTo(@0);
    //        }];
    //    }else{
    //        [self.navgationView mas_updateConstraints:^(MASConstraintMaker *make) {
    //            make.height.equalTo(@44);
    //        }];
    //    }
}

- (void)setHideBackBtn:(BOOL)hideBackBtn{
    _hideBackBtn = hideBackBtn;
    self.navgationView.btnLeft.hidden = hideBackBtn;
}

- (void)setTitle:(NSString *)title{
    [super setTitle:title];
    self.navgationView.titleLabel.text = title;
}

//#pragma mark getter
//- (TabbarController *)tabbarController{
//    AppDelegate *appdelegate = APPDELEGATE;
//    return appdelegate.tabbarController;
//}

- (NavgationView *)navgationView{
    if (!_navgationView) {
        
      CGFloat  width = [[UIScreen mainScreen] bounds].size.width;
        _navgationView = [[NavgationView alloc] initWithFrame:CGRectMake(0, 0, width, 64)];
        [_navgationView setDelegate:self];
        [_navgationView.btnLeft addTarget:self action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        _navgationView.clipsToBounds = YES;
        [self.view addSubview:_navgationView];
//        [_navgationView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.view.mas_top).offset(0);
//            make.left.equalTo(self.view.mas_left);
//            make.height.equalTo(@64);
//            make.right.equalTo(self.view.mas_right);
//        }];
    }
    return _navgationView;
}

@end




#import "AppInitializeConfig.h"
#import "Define.h"
#import "Masonry.h"

//@interface NavgationView ()
//
//@property (nonatomic, assign) NSInteger timeCount;
//@property (nonatomic, strong) NSDate *timeSpace;
//
//@end
//
//@implementation NavgationView
//
//- (instancetype)initWithFrame:(CGRect)frame{
//    if (self = [super initWithFrame:frame]) {
//        [self makeConstraints];
//        
//        SEL select = @selector(tapGestureRecognizerAction);
//        UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action: select];
//        [self addGestureRecognizer:gesture];
//    }
//    return self;
//}
//
//- (void)makeConstraints{
////    [super makeConstraints];
//    [self.bgImgView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.edges.mas_equalTo(UIEdgeInsetsZero);
//    }];
//    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.equalTo(self.mas_centerX);
//        make.top.equalTo(self.mas_top).offset(20);
//        make.width.equalTo(@150);
//        make.height.equalTo(@44);
//    }];
//    [self.btnLeft mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.top.equalTo(self.mas_top).offset(20);
//        make.left.equalTo(self.mas_left).offset(15);
//        make.height.equalTo(@44);
//        make.width.equalTo(@60);
//    }];
//}
//
//- (void)tapGestureRecognizerAction {
//    
//    if (self.timeSpace == nil) {
//        self.timeSpace = [NSDate date];
//        self.timeCount = 1;
//    }
//    
//    else {
//        NSDate *dateNow = [NSDate date];
//        NSInteger timeTemp = (NSInteger)((dateNow.timeIntervalSinceNow - self.timeSpace.timeIntervalSinceNow) * 1000);
//        if (timeTemp <= 500 ) {
//            self.timeSpace = dateNow;
//            self.timeCount++;
//        }
//        
//        else {
//            self.timeSpace = dateNow;
//            self.timeCount = 1;
//        }
//    }
//    
//    if (self.timeCount < 5) {
//        return;
//    }
//    
//    self.timeCount = 0;
//    self.timeSpace = nil;
//    
//    if (self.delegate != nil && [self.delegate respondsToSelector:@selector(NavgationView:TapGestureRecognizerAction:)]) {
//        [self.delegate NavgationView:self TapGestureRecognizerAction:nil];
//    }
//}
//
//
//#pragma getter
//- (UIImageView *)bgImgView{
//    if (!_bgImgView) {
//        _bgImgView = [[UIImageView alloc] initWithFrame:CGRectZero];
//        _bgImgView.image = ImageNamed(@"navbg");
//        [self addSubview:_bgImgView];
//    }
//    return _bgImgView;
//}
//
//- (UILabel *)titleLabel{
//    if (!_titleLabel) {
//        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
//        _titleLabel.textAlignment = NSTextAlignmentCenter;
//        _titleLabel.textColor = [UIColor whiteColor];
//        _titleLabel.font = kFontSystem(15.0);
//        _titleLabel.backgroundColor = [UIColor clearColor];
//        [self addSubview:_titleLabel];
//    }
//    return _titleLabel;
//}
//
//- (UIButton*)btnLeft{
//    if(!_btnLeft){
//        _btnLeft = [UIButton buttonWithType:UIButtonTypeCustom];
//        [_btnLeft setImage:ImageNamed(@"back") forState:UIControlStateNormal];
//        _btnLeft.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
//        _btnLeft.backgroundColor = [UIColor clearColor];
//        [self addSubview:_btnLeft];
//    }
//    return _btnLeft;
//}
//
//@end

/////////////原项目中 ViewController copy/////////////////////////////////

/////////////原项目中 ViewController copy/////////////////////////////////

/////////////原项目中 ViewController copy/////////////////////////////////
