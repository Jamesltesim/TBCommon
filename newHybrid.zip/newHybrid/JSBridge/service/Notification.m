//
//  Notification.m
//  HybirdApp
//
//  Created by Toby on 2018/1/18.
//  Copyright © 2018年 harden-imac. All rights reserved.
//

#import "Notification.h"

@implementation Notification

- (void)loginNotify:(NSDictionary *)data{
    if([self.delegate respondsToSelector:@selector(appInvokeNotificationForLoginNotify:)]){
        [self.delegate appInvokeNotificationForLoginNotify:data];
    }
}

- (void)logoutNotify:(NSDictionary *)data{
    if([self.delegate respondsToSelector:@selector(appInvokeNotificationForLogoutNotify:)]){
        [self.delegate appInvokeNotificationForLogoutNotify:data];
    }
}

@end
