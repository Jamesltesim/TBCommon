//
//  Cache.h
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "BaseService.h"

@interface Cache : BaseService


@end
