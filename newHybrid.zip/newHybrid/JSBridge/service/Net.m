//
//  Net.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "Net.h"

@implementation Net

- (void)invoke:(NSDictionary *)data{
    
    NSString *apiUrl = data[@"apiUrl"];
    NSString *loading = data[@"loading"];
    NSDictionary *params = data[@"params"];
    NSString *requestId = data[@"requestId"];
    
    if([self.delegate respondsToSelector:@selector(appInvokeNetWithUrl:Params:loading:requestId:)]){
        [self.delegate appInvokeNetWithUrl:apiUrl Params:params loading:[loading boolValue] requestId:requestId];
    }
}

- (NSString *)description{
    return @"Net Service";
}

@end
