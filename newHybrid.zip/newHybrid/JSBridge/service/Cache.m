//
//  Cache.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "Cache.h"

@implementation Cache

//- (void)runWithMethodName:(NSString *)name data:(NSDictionary *)data{
//    NSLog(@"服务名:%@ \n方法名 :%@  \ndata:%@",[self description],name,data);
//    
//    //method白名单
//    
//    SEL selector = NSSelectorFromString([NSString stringWithFormat:@"%@:",name]);
//    [self performSelector:selector withObject:data];
//}



#pragma mark- 跟js通信协议中的 方法
- (void)get:(NSDictionary *)data{
   
    NSString *key = data[@"key"];
    NSString *requestId = data[@"requestId"];
    if([self.delegate respondsToSelector:@selector(appInvokeCacheForGetWith:requestId:)]){
        [self.delegate appInvokeCacheForGetWith:key requestId:requestId];
    }
}

- (void)update:(NSDictionary *)data{
    if([self.delegate respondsToSelector:@selector(appInvokeCacheForUpdate:)]){
        [self.delegate appInvokeCacheForUpdate:data];
    }
}

- (void)save:(NSDictionary *)data{
    if([self.delegate respondsToSelector:@selector(appInvokeCacheForSave:)]){
        [self.delegate appInvokeCacheForSave:data];
    }
}

- (void)delete:(NSDictionary *)data{
    if([self.delegate respondsToSelector:@selector(appInvokeCacheForDelete:)]){
        [self.delegate appInvokeCacheForDelete:data];
    }
}

- (void)clear:(NSDictionary *)data{
    if([self.delegate respondsToSelector:@selector(appInvokeCacheForClear:)]){
        [self.delegate appInvokeCacheForClear:data];
    }
}

#pragma mark - data 存取
-(BOOL)writeWithValue:(NSString *)value key:(NSString *)key;
{
    BOOL isSucceed = NO;

        NSAssert(value == nil || key == nil, @"cache service: writeWithValue key =nil or value = nil");
    
    NSString *dicPath =[[TTTools documentPath] stringByAppendingString:@"/cache.txt"];
    NSDictionary * dic = [NSDictionary dictionaryWithObject:value forKey:key];
    BOOL state = [dic writeToFile:dicPath atomically:YES];
    if (state == YES) {
//        NSLog(@"write successfully");
        isSucceed = YES;
    }else{
//        NSLog(@"fail to write");
        isSucceed = NO;
    }
    return isSucceed;
}

-(NSString *)readWithKey:(NSString *)key{

    NSAssert(key == nil, @"cache service: readWithKey key =nil");
    
    NSString *dicPath =[[TTTools documentPath] stringByAppendingString:@"/cache.txt"];
    NSDictionary * dic = [NSDictionary dictionaryWithContentsOfFile:dicPath];
    NSLog(@"dic == %@",dic);
    
    return dic[key];
    
}


#pragma mark- life cycle
- (NSString *)description{
    return @"Cache Service";
}

@end
