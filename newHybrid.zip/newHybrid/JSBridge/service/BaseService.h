//
//  BaseService.h
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AppInvokeDelegate.h"
#import "TTTools.h"

@interface BaseService : NSObject

@property (nonatomic,weak) id<AppInvokeDelegate> delegate;

- (void)runWithMethodName:(NSString *)name data:(NSDictionary *)data;

@end
