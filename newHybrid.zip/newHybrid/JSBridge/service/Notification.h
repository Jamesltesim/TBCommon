//
//  Notification.h
//  HybirdApp
//
//  Created by Toby on 2018/1/18.
//  Copyright © 2018年 harden-imac. All rights reserved.
//

#import "BaseService.h"

@interface Notification : BaseService

@end
