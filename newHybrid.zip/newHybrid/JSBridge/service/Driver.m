//
//  Driver.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "Driver.h"

@implementation Driver

//- (void)runWithMethodName:(NSString *)name data:(NSDictionary *)data{
//    if([self.delegate respondsToSelector:@selector(appInvokeDriverWithData:)]){
//        [self.delegate appInvokeDriverWithData:data];
//    }
//}

- (void)live800:(NSDictionary *)data{
    NSInteger customerId = [data[@"customer_id"] integerValue];
    
    if([self.delegate respondsToSelector:@selector(appInvokeDriverForLive800:)]){
        [self.delegate appInvokeDriverForLive800:customerId];
    }
}
- (void)live800ol:(NSDictionary *)data {
     NSInteger customerId = [data[@"customer_id"] integerValue];
    if([self.delegate respondsToSelector:@selector(appInvokeDriverForLive800ol:)]){
        [self.delegate appInvokeDriverForLive800ol:customerId];
    }
}


- (void)getSessionId:(NSDictionary *)data{
    NSString *requestId = data[@"requestId"];
    if([self.delegate respondsToSelector:@selector(appInvokeDriverForGetSessionIdWithRequestId:)]){
        [self.delegate appInvokeDriverForGetSessionIdWithRequestId:requestId];
    }
    
}
- (void)deviceInfo:(NSDictionary *)data{
    NSString *requestId = data[@"requestId"];
    if([self.delegate respondsToSelector:@selector(appInvokeDriverForDeviceInfoWithRequestId:)]){
        [self.delegate appInvokeDriverForDeviceInfoWithRequestId:requestId];
    }
}


- (void)game:(NSDictionary *)data{
    NSString *requestId = data[@"requestId"];
    if([self.delegate respondsToSelector:@selector(appInvokeDriverForGame:)]){
        [self.delegate appInvokeDriverForGame:data];
    }
}

- (void)clearCookie:(NSDictionary *)data {
    if([self.delegate respondsToSelector:@selector(appInvokeDriverForClearCookie:)]){
        [self.delegate appInvokeDriverForClearCookie:data];
    }
}

- (void)printLog:(NSDictionary *)data{
    
    NSString *level = data[@"level"];
    NSString *log = data[@"log"];
    NSLog(@"=============  JS Log ** level:%@  =============  \n  %@ \n =======================================",level,log);
}

- (NSString *)description{
    return @"Driver Service";
}

@end
