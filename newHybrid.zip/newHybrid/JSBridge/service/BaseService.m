//
//  BaseService.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "BaseService.h"
#import "HybridHandle.h"
@implementation BaseService

- (void)runWithMethodName:(NSString *)name data:(NSDictionary *)data{
    
    if([HybridHandle shareHybridHandle].jsCallNativeForPrintLog){
        NSLog(@"\n--------------  %@  -------------------\n\n        --->>> method: %@  <<<---\n         --->>> params: %@  \n\n--------------------------------------------------------\n",
              [self description],name,data);
    }
   
    
    
    SEL selector = NSSelectorFromString([NSString stringWithFormat:@"%@:",name]);
    if([self respondsToSelector:selector]){
        
        [self performSelector:selector withObject:data];
        
    }else{
        NSAssert(0, @"JSBrisge -> js端发送过来的 服务 -> 对应的方法(%@) 没有实现",name);
    }
    
}

- (NSString *)description{
    return @"BaseService";
}

@end

