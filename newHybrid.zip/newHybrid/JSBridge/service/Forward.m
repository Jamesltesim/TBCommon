//
//  Forward.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "Forward.h"

@implementation Forward


#pragma mark- 跟js通信协议中的 方法


//- (void)runWithMethodName:(NSString *)name data:(NSDictionary *)data{
//    NSLog(@"%@ name: %@  data: %@",[self description],name,data);
//}

//zip中本地的html
- (void)inside:(NSDictionary *)data{
    
    //browser = 1用外部浏览器打开
    //browser = 0
    NSString *browser = data[@"browser"];
    
    NSString *newView = data[@"newView"];
    NSString *requestId = data[@"requestId"];
    
    //定制带返回按钮的导航栏
    NSString *theme = data[@"theme"];
    NSString *url = data[@"url"];
    
    if( [self.delegate respondsToSelector:@selector(appInvokeForwardToInsideWithUrl:browser:newView:theme:gameType:requestId:)]){
        [self.delegate appInvokeForwardToInsideWithUrl:url browser:[browser boolValue] newView:[newView boolValue] theme:[theme boolValue] gameType:@"" requestId:requestId];
    }
    
    
}

//
- (void)outside:(NSDictionary *)data{
    
    //browser = 1用外部浏览器打开
    //browser = 0
    NSString *browser = data[@"browser"];
    
    //
    NSString *newView = data[@"newView"];
    NSString *requestId = data[@"requestId"];
    //定制带返回按钮的导航栏
    NSString *theme = data[@"theme"];
    NSString *url = data[@"url"];
    if( [self.delegate respondsToSelector:@selector(appInvokeForwardToOutsideWithUrl:browser:newView:theme:gameType:requestId:)]){
        [self.delegate appInvokeForwardToOutsideWithUrl:url browser:[browser boolValue] newView:[newView boolValue] theme:[theme boolValue] gameType:@"" requestId:requestId];
    }
}

#pragma mark- life cycle
- (NSString *)description{
    
    return @"Forward Service";
}

@end
