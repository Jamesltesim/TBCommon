//
//  AppInvoke.h
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AppInvokeDelegate;


@interface AppInvoke : NSObject


- (AppInvoke * (^)(NSString *name))service;

- (AppInvoke * (^)(NSString *name,NSDictionary *data))method;

- (void (^)(NSString *requestId))jsCallback;


- (void)registerDelegate:(id <AppInvokeDelegate>)delegate forAppInvokeWithReuseIdentifier:(NSString *)identifier;



    
@end
