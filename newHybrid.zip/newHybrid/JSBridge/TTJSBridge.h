//
//  TTJSBridge.h
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>
#import "AppInvokeDelegate.h"
@class AppInvoke;

@interface TTJSBridge : NSObject

/**
 JS交互入口名
 JSBridgeName 是跟js端约定好的唯一交互入口，
 如果跟js端不相同，TTJSBridge不会工作.log输出：‘JS入口协议 非法,  JSBridge 停止’
 */
@property (nonatomic,strong,readonly) NSString * _Nullable JSBridgeName;

@property (nonatomic,strong) AppInvoke * _Nonnull appInvoke;




- (void)addCookieScript:(WKUserScript *)script;


//init
+ (instancetype _Nonnull )instance;
+ (instancetype _Nonnull )instanceWithDelegate:(_Nonnull id  <AppInvokeDelegate>)delegate;
+ (instancetype _Nonnull )instanceWithWKWebView:(WKWebView *_Nullable)webView;
+ (instancetype _Nonnull)instanceWithWKWebView:(WKWebView *_Nullable)webView delegate:(_Nonnull id  <AppInvokeDelegate>)delegate;

/**
 与网页端通讯，js调用 native。
 接收js发过来的消息。

 @param message js发过来的消息
 */
- (void)getJSMessage:(WKScriptMessage *_Nonnull)message;

/**
 目前没完成
 */
- (void)evaluateJavaScriptWithDictionary:(NSDictionary *_Nonnull)params completionHandler:(void (^ _Nullable)(_Nullable id, NSError * _Nullable error))completionHandler;

/**
 native 调用js。
 内部使用跟网页端协商好的方法，传入ParamString参数，统一调用。

 @param ParamString js代码，拼接成参数字符串
 
 @param completionHandler completionHandler description
 */
- (void)evaluateJavaScriptWithParamString:(NSString *_Nonnull)ParamString completionHandler:(void (^ _Nullable)(_Nullable id, NSError * _Nullable error))completionHandler;


- (void)evaluateJavaScriptWithParamString:(NSString *_Nonnull)ParamString reuseIdentifier:(nullable NSString *)reuseIdentifier completionHandler:(void (^ _Nullable)(_Nullable id, NSError * _Nullable error))completionHandler;

//临时判断
+ (BOOL)gotoWk:(NSString *_Nonnull)url;
@end


