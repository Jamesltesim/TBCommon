//
//  AppInvokeCacheDelegate.h
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol AppInvokeDelegate <NSObject>

@optional

#pragma mark- Forward delegate

//app内部跳转界面
- (void)appInvokeForwardToInsideWithUrl:(NSString *)url browser:(BOOL)browser newView:(BOOL)newView theme:(BOOL)theme gameType:(NSString *)gameType requestId:(NSString *)requestId;


//从app跳转到safari
- (void)appInvokeForwardToOutsideWithUrl:(NSString *)url browser:(BOOL)browser newView:(BOOL)newView theme:(BOOL)theme gameType:(NSString *)gameType requestId:(NSString *)requestId;


#pragma mark- Net delegate

- (void)appInvokeNetWithUrl:(NSString *)url Params:(NSDictionary *)params loading:(BOOL)loading requestId:(NSString *)requestId;


#pragma mark- Cache delegate
- (void)appInvokeCacheForGetWith:(NSString *)key requestId:(NSString *)requestId;

- (void)appInvokeCacheForUpdate:(NSDictionary *)data;

- (void)appInvokeCacheForSave:(NSDictionary *)data;

- (void)appInvokeCacheForClear:(NSDictionary *)data;

- (void)appInvokeCacheForDelete:(NSDictionary *)data;


#pragma mark- Driver delegate

//live800
- (void)appInvokeDriverForLive800:(NSInteger)customerId;
- (void)appInvokeDriverForLive800ol:(NSInteger)customerId;

- (void)appInvokeDriverForGetSessionIdWithRequestId:(NSString *)requestId;

- (void)appInvokeDriverForDeviceInfoWithRequestId:(NSString *)requestId;

- (void)appInvokeDriverWithData:(NSDictionary *)data;

- (void)appInvokeDriverForGame:(NSDictionary *)data;
- (void)appInvokeDriverForClearCookie:(NSDictionary *)data;
#pragma mark- Notification delegate
- (void)appInvokeNotificationForLoginNotify:(NSDictionary *)data;


- (void)appInvokeNotificationForLogoutNotify:(NSDictionary *)data;
@end
