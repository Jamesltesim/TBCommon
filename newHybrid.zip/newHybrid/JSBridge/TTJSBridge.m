//
//  TTJSBridge.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "TTJSBridge.h"
#import "JSBridgeInterface.h"
#import "AppInvoke.h"
#import "TTTools.h"

@interface TTJSBridge()

@property (nonatomic,strong) WKWebView *wkWebView;
@property (nonatomic,weak) id <AppInvokeDelegate> delegate;
@end

@implementation TTJSBridge

#pragma mark- 公开方法

//注入cookie
- (void)addCookieScript:(WKUserScript *)script{
    if(_wkWebView && script){
        [_wkWebView.configuration.userContentController addUserScript:script];
    }
}

- (void)getJSMessage:(WKScriptMessage *)message{
    
    NSAssert([message.name isEqualToString:self.JSBridgeName], @"JS入口协议 非法,  JSBridge 停止");

//    NSLog(@"data:%@   method:%@   service:%@  requestId:%@",data,method,service,requestId);
    NSDictionary *dict = [TTTools dictionaryWithJsonString:message.body];
    NSString *service = dict[TT_SERVICE];
    NSString *method = dict[TT_METHOD];
    NSString *requestId = dict[TT_REQUESTID];
    
    NSMutableDictionary *data = [[NSMutableDictionary alloc]initWithCapacity:0];
    if([[dict allKeys] containsObject:TT_DATA]){
        [data setDictionary:dict[TT_DATA]];
    }
    [data setObject:requestId forKey:TT_REQUESTID];
    
    
    self.appInvoke.service(service).method(method,data);
}

//- (void)evaluateJavaScript:(NSString *)javaScriptString completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler{
//    [self.wkWebView evaluateJavaScript:javaScriptString completionHandler:completionHandler];
//}

- (void)evaluateJavaScriptWithParamString:(NSString *)ParamString completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler{
    

     [self.wkWebView evaluateJavaScript:[NSString stringWithFormat:@"JSCallback(%@)",ParamString] completionHandler:completionHandler];
//    [self evaluateJavaScript:[NSString stringWithFormat:@"JSCallback(%@)",ParamString] completionHandler:completionHandler];
}

- (void)evaluateJavaScriptWithParamString:(NSString *_Nonnull)ParamString reuseIdentifier:(nullable NSString *)reuseIdentifier completionHandler:(void (^ _Nullable)(_Nullable id, NSError * _Nullable error))completionHandler{
    
    NSLog(@"native -> js ~ ^ ~ %@ \n :%@",reuseIdentifier,[NSString stringWithFormat:@"JSCallback(%@)",ParamString]);
    [self evaluateJavaScriptWithParamString:ParamString completionHandler:completionHandler];
    
}

- (void)evaluateJavaScriptWithDictionary:(NSDictionary *)params completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler{
    
    
//    [self evaluateJavaScriptWithParamString:@"" completionHandler:completionHandler];
}
#pragma mark- life cycle
    
+ (instancetype)instance{
    TTJSBridge *bridge = [[TTJSBridge alloc] init];
    bridge.appInvoke = [[AppInvoke alloc]init];
    return bridge;
}

+ (instancetype)instanceWithDelegate:(id<AppInvokeDelegate>)delegate{
    TTJSBridge *bridge = [self instance];
//    bridge.delegate = delegate;
    [bridge.appInvoke registerDelegate:delegate forAppInvokeWithReuseIdentifier:@""];
    return bridge;
}

+ (instancetype)instanceWithWKWebView:(WKWebView *)webView{
    TTJSBridge *bridge = [self instance];
    bridge.wkWebView = webView;
    return bridge;
}

+ (instancetype)instanceWithWKWebView:(WKWebView *)webView delegate:(id<AppInvokeDelegate>)delegate{
    TTJSBridge *bridge = [self instance];
    bridge.wkWebView = webView;
    [bridge.appInvoke registerDelegate:delegate forAppInvokeWithReuseIdentifier:@""];
    return bridge;
}
#pragma mark- set get
    
- (NSString *)JSBridgeName{
    return JSBRIDGE_NAME;
}

#pragma mark- 临时
+ (BOOL)gotoWk:(NSString *)url{
    BOOL flog = NO;
    
    if([url isEqualToString:@"common/login.htm"]){
        flog = YES;
    }
    return flog;
}
@end
