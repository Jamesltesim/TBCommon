//
//  JSBridgeInterface.h
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//



// unique,  js and native enter
#define JSBRIDGE_NAME  @"appInvoke"


//js call native , Params
#define TT_DATA            @"data"
#define TT_METHOD          @"method"
#define TT_SERVICE         @"service"
#define TT_REQUESTID       @"requestId"


// 本地html在沙盒中的位置
#define TT_WebAppPath   [NSString stringWithFormat:@"%@/webApp",[NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0]]
