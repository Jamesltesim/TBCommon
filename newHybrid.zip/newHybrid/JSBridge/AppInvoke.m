//
//  AppInvoke.m
//  WKTest01
//
//  Created by Toby on 2018/1/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "AppInvoke.h"
#import "BaseService.h"
#import "HybridHandle.h"

@interface AppInvoke()

@property(nonatomic, weak) id <AppInvokeDelegate> delegate;

@property (nonatomic,strong) __block BaseService *currentService;

//base service white list
@property (nonatomic,strong) NSDictionary *serviceWhiteListDictionary;

@end

@implementation AppInvoke

#pragma mark- set get

- (AppInvoke * (^)(NSString *))service{
    
    return ^(NSString *name){
        
        if([self checkWhiteListWithServiceName:name]){
            
            Class class = NSClassFromString([name capitalizedString]);
            _currentService = [[class alloc]init];
            _currentService.delegate = self.delegate;
            
        }else{
            NSAssert(0, @"JSBrisge -> 当前注册的 服务 非法");
            return self;
        }
        return self;
    };
}

- (AppInvoke * (^)(NSString *,NSDictionary *))method{
    
    return ^(NSString *name,NSDictionary *data){
        if(_currentService){
            [_currentService runWithMethodName:name data:data];
        }else{
            NSLog(@"需要先确认服务名称，再执行方法");
        }
        
        return self;
    };
}

- (void (^)(NSString *))jsCallback{
    
    return ^(NSString *name){
        
    };
}

- (NSDictionary *)serviceWhiteListDictionary{

    if(!_serviceWhiteListDictionary){
        
        NSMutableDictionary *services = [[NSMutableDictionary alloc]initWithDictionary:@{@"cache":[NSNumber numberWithBool:YES],
                                                                                         @"driver":[NSNumber numberWithBool:YES],
                                                                                         @"net":[NSNumber numberWithBool:YES],
                                                                                         @"forward":[NSNumber numberWithBool:YES],
                                                                                         @"notification":[NSNumber numberWithBool:YES]
                                                                                         }];
        
        for (NSString *service in [HybridHandle getNewServices]){
            
            [services setObject:[NSNumber numberWithBool:YES] forKey:service];
            
        }
        
        _serviceWhiteListDictionary = [[NSDictionary alloc] initWithDictionary:services];
    }
    
    return _serviceWhiteListDictionary;
}

- (BOOL)checkWhiteListWithServiceName:(NSString *)name{
    return [[self.serviceWhiteListDictionary objectForKey:name] boolValue];
}



#pragma mark- 公开方法
- (void)registerDelegate:(id<AppInvokeDelegate>)delegate forAppInvokeWithReuseIdentifier:(NSString *)identifier{
    _delegate = delegate;
}


@end
