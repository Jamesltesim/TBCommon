//
//  HybridHandle.h
//  HybirdApp
//
//  Created by Toby on 2018/1/9.
//  Copyright © 2018年 harden-imac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HybridHandle : NSObject

@property (nonatomic) BOOL jsCallNativeForPrintLog;
@property (nonatomic) BOOL nativeCallJsForPrintLog;

+(instancetype)shareHybridHandle;

+ (BOOL)

/**
 
 扩展TTJSBridge的 service 服务
 
 */
+ (void)registerService:(NSString *)serviceName;
+ (void)registerServices:(NSArray *)serviceNames;
+ (NSArray *)getNewServices;
/**
 检查本地基础html包

 */
+ (BOOL)checkBasePackage;

/**

 
 */
+ (BOOL)checkPlugPackage;


//plug-in
+ (void)initializeApplePushNotificationService;
@end
