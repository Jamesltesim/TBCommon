//
//  TTScrollContentCell.h
//  TTScrollView
//
//  Created by Toby on 2018/2/6.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTScrollContentCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;
@property (weak, nonatomic) IBOutlet UILabel *name;

@property (weak, nonatomic) IBOutlet UILabel *price;
@end
