//
//  TTScrollView.h
//  TTScrollView
//
//  Created by Toby on 2018/2/6.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TTContentModel.h"
#import "TTIndexPath.h"

@protocol TTScrollViewDelegate;

@interface TTScrollView : UIView

@property (nonatomic,weak) id<TTScrollViewDelegate>delegate;

- (void)reloadData;
@end

@protocol TTScrollViewDelegate<NSObject>

- (CGFloat)titleView:(UITableView *)titleView heightForRowAt:(NSInteger)row;
- (NSInteger)titleView:(UITableView *)titleView numberOfRowsIn:(NSInteger)row;
- (NSInteger)numberOfSectionsInTitleView:(UITableView *)titleView;
- (NSString *)titleView:(UITableView *)titleView titleForRowAt:(NSInteger)row;


- (CGFloat)contentView:(UITableView *)contentView heightForRowAt:(NSInteger)row;
- (NSInteger)numberOfSectionsInContentView:(UITableView *)contentView;
- (TTContentModel *)contentView:(UITableView *)contentView contentForRowAtIndexPath:(TTIndexPath *)indexPath;

- (void)scrollView:(UITableView *)tableView didSelectRowAtIndexPath:(TTIndexPath *)indexPath;

@end
