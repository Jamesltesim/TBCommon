//
//  AppDelegate.h
//  TTScrollView
//
//  Created by Toby on 2018/2/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

