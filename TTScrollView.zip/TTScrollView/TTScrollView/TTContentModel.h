//
//  TTContentModel.h
//  TTScrollView
//
//  Created by Toby on 2018/2/6.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTContentModel : NSObject

@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *imgUrl;
@property (nonatomic) CGFloat price;

@end
