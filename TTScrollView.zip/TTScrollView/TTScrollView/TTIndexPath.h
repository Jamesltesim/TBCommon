//
//  TTIndexPath.h
//  TTScrollView
//
//  Created by Toby on 2018/2/6.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TTIndexPath : NSObject

@property (nonatomic) NSInteger titleRow;
@property (nonatomic) NSInteger contentRow;

@end
