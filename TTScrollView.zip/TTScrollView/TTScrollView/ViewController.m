//
//  ViewController.m
//  TTScrollView
//
//  Created by Toby on 2018/2/5.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "ViewController.h"
#import "TTScrollView.h"

@interface ViewController ()<TTScrollViewDelegate>

@property (nonatomic,strong) NSArray *titleArray;
@property (nonatomic,strong) NSArray *contentArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    self.titleArray = @[@"1",@"2",@"3",@"4"];
    
    NSMutableArray *marr1 = [[NSMutableArray alloc]initWithCapacity:0];
    for(int i=0;i<self.titleArray.count;i++){
        NSMutableArray *marr = [[NSMutableArray alloc]initWithCapacity:0];
        for(int j=0;j<4;j++){
            TTContentModel *model = [TTContentModel new];
            model.imgUrl = @"aa";
            model.name = [NSString stringWithFormat:@"name :%d",j*i];
            model.price = j*i;
            [marr addObject:model];
        }
        [marr1 addObject:marr];
    }
    self.contentArray = marr1;
    
    TTScrollView *view = [[TTScrollView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-50)];
    view.delegate = self;
    [self.view addSubview:view];
    
    UIButton *btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn1.frame = CGRectMake(0, view.frame.origin.y+view.frame.size.height, self.view.frame.size.width/2, 50);
    [btn1 setTitle:@"管理分类" forState:UIControlStateNormal];
    [btn1 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(categoryManage:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
    btn2.frame = CGRectMake(self.view.frame.size.width/2, view.frame.origin.y+view.frame.size.height, self.view.frame.size.width/2, 50);
    [btn2 setTitle:@"新建商品" forState:UIControlStateNormal];
    [btn2 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(createGood:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
}

- (void)categoryManage:(UIButton *)sender {
    NSLog(@"categoryManage");
}

- (void)createGood:(UIButton *)sender {
    NSLog(@"createGood");
}

- (CGFloat)titleView:(UITableView *)titleView heightForRowAt:(NSInteger)row{
    return 40;
}

- (NSInteger)numberOfSectionsInTitleView:(UITableView *)titleView{
    return self.titleArray.count;
}

- (NSString *)titleView:(UITableView *)titleView titleForRowAt:(NSInteger)row{
    return self.titleArray[row];
}

- (NSInteger)numberOfSectionsInContentView:(UITableView *)contentView{
    return self.contentArray.count;
}

- (TTContentModel *)contentView:(UITableView *)contentView contentForRowAtIndexPath:(TTIndexPath *)indexPath{
    
    NSArray *content = self.contentArray[indexPath.titleRow];
    return content[indexPath.contentRow];
}

- (void)scrollView:(UITableView *)tableView didSelectRowAtIndexPath:(TTIndexPath *)indexPath{
    NSLog(@"title row:%ld  content row:%ld",indexPath.titleRow,indexPath.contentRow);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
