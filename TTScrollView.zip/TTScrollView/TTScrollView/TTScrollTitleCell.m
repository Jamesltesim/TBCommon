//
//  TTScrollTitleCell.m
//  TTScrollView
//
//  Created by Toby on 2018/2/6.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "TTScrollTitleCell.h"

@implementation TTScrollTitleCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
