//
//  TTScrollView.m
//  TTScrollView
//
//  Created by Toby on 2018/2/6.
//  Copyright © 2018年 Toby. All rights reserved.
//

#import "TTScrollView.h"
#import "TTScrollTitleCell.h"
#import "TTScrollContentCell.h"

#define widthScale  0.32


@interface TTScrollView()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic,strong) UITableView *titleView;
@property (nonatomic,strong) UITableView *contentView;

@property (nonatomic) NSInteger currentTitleIndex;

@end

@implementation TTScrollView

#pragma mark - 公开方法

- (void)reloadData{
    [self.titleView reloadData];
    [self.contentView reloadData];
}

#pragma mark - life cycle

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self addSubview:self.titleView];
        [self addSubview:self.contentView];
        self.currentTitleIndex = 0;
    }
    return self;
}

#pragma mark - set get

- (UITableView *)titleView{
    if(!_titleView){
        _titleView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width*widthScale, self.frame.size.height) style:UITableViewStylePlain];
        _titleView.delegate = self;
        _titleView.dataSource = self;
        _titleView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _titleView;
}

- (UITableView *)contentView{
    if(!_contentView){
        _contentView = [[UITableView alloc]initWithFrame:CGRectMake(self.frame.size.width*widthScale, 0, self.frame.size.width*(1-widthScale), self.frame.size.height) style:UITableViewStylePlain];
        _contentView.delegate = self;
        _contentView.dataSource = self;
        _contentView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _contentView;
}

#pragma mark - tableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if(tableView == self.titleView){
        if([self.delegate respondsToSelector:@selector(titleView:heightForRowAt:)]){
            return [self.delegate titleView:tableView heightForRowAt:indexPath.row];
        }else{
            return 48;
        }
    }else if (tableView == self.contentView){
        if([self.delegate respondsToSelector:@selector(contentView:heightForRowAt:)]){
            return [self.delegate contentView:tableView heightForRowAt:indexPath.row];
        }else{
            return 115;
        }
    }
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(tableView == self.titleView){
        if([self.delegate respondsToSelector:@selector(numberOfSectionsInTitleView:)]){
            return [self.delegate numberOfSectionsInTitleView:tableView];
        }
    }else{
        if([self.delegate respondsToSelector:@selector(numberOfSectionsInContentView:)]){
            return [self.delegate numberOfSectionsInContentView:tableView];
        }
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(tableView == self.titleView){
    
        TTScrollTitleCell *cell= [[[NSBundle mainBundle] loadNibNamed:@"TTScrollTitleCell" owner:nil options:nil] lastObject];
        if([self.delegate respondsToSelector:@selector(titleView:titleForRowAt:)]){
            cell.textLabel.text = [self.delegate titleView:tableView titleForRowAt:indexPath.row];
        }
        return cell;
    }else if (tableView ==self.contentView){
        
        TTScrollContentCell *cell= [[[NSBundle mainBundle] loadNibNamed:@"TTScrollContentCell" owner:nil options:nil] lastObject];
        
        TTContentModel *model = nil;
        if([self.delegate respondsToSelector:@selector(contentView:contentForRowAtIndexPath:)]){
            TTIndexPath *ttIndexpath = [TTIndexPath new];
            ttIndexpath.titleRow = self.currentTitleIndex;
            ttIndexpath.contentRow = indexPath.row;
            
            model = [self.delegate contentView:tableView contentForRowAtIndexPath:ttIndexpath];
            cell.name.text = model.name;
            cell.price.text = [NSString stringWithFormat:@"%.2f",model.price];
        }
        
        return cell;
    }
    return [UITableViewCell new];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if(self.titleView == tableView){
        self.currentTitleIndex = indexPath.row;
        [self.contentView reloadData];
    }else if (self.contentView == tableView){
        
        if([self.delegate respondsToSelector:@selector(scrollView:didSelectRowAtIndexPath:)]){
            TTIndexPath *ttIndexpath = [TTIndexPath new];
            ttIndexpath.titleRow = self.currentTitleIndex;
            ttIndexpath.contentRow = indexPath.row;
            [self.delegate scrollView:tableView didSelectRowAtIndexPath:ttIndexpath];
        }
    }
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
