//
//  ViewController.m
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "ViewController.h"
#import "ShowGoodsView.h"

@interface ViewController ()<ShowGoodsViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    ShowGoodsView *view = [[ShowGoodsView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    
    
    GoodsDataHandle *dataHandle = [[GoodsDataHandle alloc] init];
    dataHandle.dataArray =  @[@[@{@"Aa":@[@{@"title":@"a1",@"goodid":@"10001",@"price":@(100)},
                                         @{@"title":@"a2",@"goodid":@"10001",@"price":@(110)},
                                         @{@"title":@"a3",@"goodid":@"10001",@"price":@(120)},
                                         @{@"title":@"a4",@"goodid":@"10001",@"price":@(130)}
                                         ]
                                  }
                                ],
                              
                              @[@{@"Bb":@[@{@"title":@"b1",@"goodid":@"10001",@"price":@(190)},
                                         @{@"title":@"b2",@"goodid":@"10001",@"price":@(160)},
                                         @{@"title":@"b3",@"goodid":@"10001",@"price":@(110)},
                                         @{@"title":@"b4",@"goodid":@"10001",@"price":@(100)}
                                         ]
                                  }
                                ],
                              
                              @[@{@"C":@[@{@"title":@"c1",@"goodid":@"10001",@"price":@(75)},
                                         @{@"title":@"c2",@"goodid":@"10001",@"price":@(45)},
                                         @{@"title":@"c3",@"goodid":@"10001",@"price":@(95)},
                                         @{@"title":@"c4",@"goodid":@"10001",@"price":@(100)}]}],
                              
                              @[@{@"D":@[@{@"title":@"d1",@"goodid":@"10001",@"price":@(80)},
                                         @{@"title":@"d2",@"goodid":@"10001",@"price":@(120)},
                                         @{@"title":@"d3",@"goodid":@"10001",@"price":@(130)},
                                         @{@"title":@"d4",@"goodid":@"10001",@"price":@(100)}]}]
                              ];
    
    view.delegate = self;
    [view updateDataHandleWtih:dataHandle];
    
    view.contentTabViewCellHeight = 120;
    [self.view addSubview:view];
    
//    NSLog(@"mark:%@",dataHandle.markTitleDictionary);
}

- (void)showGoodsView:(ShowGoodsView *)goodView didSelectItemAtGoodIndexPath:(GoodIndexPath *)goodIndex{
    NSLog(@"select   类别:%@ goodId:%@  位置:%ld",goodIndex.titleKey,goodIndex.goodId,goodIndex.row);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
