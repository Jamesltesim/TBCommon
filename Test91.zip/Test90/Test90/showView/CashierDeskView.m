//
//  CashierDeskView.m
//  Test90
//
//  Created by Toby on 2017/11/20.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "CashierDeskView.h"

#define CashierDeskBackGroundColor [UIColor colorWithRed:48/255.0 green:48/255.0 blue:48/255.0 alpha:0.8]
@interface CashierDeskView()

@property (nonatomic,strong) UIButton *accountButton;

@property (nonatomic,strong) UILabel *deliveryFeeLab;
@property (nonatomic,strong) UILabel *priceLab;
@property (nonatomic,strong) UILabel *redDot;

@property (nonatomic,strong) UILabel *deliveryStandardLab;
@end

@implementation CashierDeskView

- (void)showPriceCaption{
    self.deliveryFeeLab.center = CGPointMake(100+30, self.frame.size.height/2+self.deliveryFeeLab.frame.size.height/2);
    self.priceLab.hidden = NO;
}

- (void)hidePriceCaption{
    self.deliveryFeeLab.center = CGPointMake(100+30,self.frame.size.height/2);
    self.priceLab.hidden = YES;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.deliveryStandard = 2000;
        self.backgroundColor = CashierDeskBackGroundColor;
        [self addSubview:self.priceLab];
        [self.priceLab addSubview:self.redDot];
        
        [self addSubview:self.deliveryFeeLab];
        [self addSubview:self.deliveryStandardLab];
        [self addSubview:self.accountButton];
    }
    return self;
}

- (void)changeCashierWithMoney:(NSInteger)money redDot:(NSInteger)number{
    _priceLab.text = [NSString stringWithFormat:@"¥ %ld",money];
    
    //小红点设计
    if(money > 0){
//        显示
        self.redDot.hidden = NO;
        self.redDot.text = [NSString stringWithFormat:@"%ld",number];
    }else{
//        不显示
        self.redDot.hidden = YES;
    
    }
    
    //右侧部分设计
    if(money == 0){
        self.deliveryStandardLab.hidden = NO;
        self.accountButton.hidden = YES;
        self.deliveryStandardLab.text = [NSString stringWithFormat:@"¥%ld 起送",self.deliveryStandard];
    }else if ((self.deliveryStandard-money) > 0){
        self.deliveryStandardLab.hidden = NO;
        self.accountButton.hidden = YES;
        self.deliveryStandardLab.text = [NSString stringWithFormat:@"差¥%ld 起送",(self.deliveryStandard-money)];
        
    }else if ((self.deliveryStandard-money) <= 0){
        self.deliveryStandardLab.hidden = YES;
        self.accountButton.hidden = NO;
    }
    
    
}

- (UILabel *)redDot{
    if(!_redDot){
        _redDot = [[UILabel alloc]initWithFrame:CGRectMake(-15, -7, 15, 15)];
        _redDot.layer.cornerRadius= 7.5;
        _redDot.layer.masksToBounds = YES;
        _redDot.hidden = YES;
        _redDot.font = [UIFont systemFontOfSize:12];
        _redDot.textColor = [UIColor whiteColor];
        _redDot.backgroundColor = [UIColor colorWithRed:232/255.0 green:97/255.0 blue:86/255.0 alpha:1];
        _redDot.textAlignment = NSTextAlignmentCenter;
    }
    return _redDot;
}

- (UILabel *)priceLab{
    if(!_priceLab){
        _priceLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 300, 20)];
        _priceLab.font = [UIFont systemFontOfSize:18];
        _priceLab.text = [NSString stringWithFormat:@"¥ 0"];
        _priceLab.center = CGPointMake(150+30,self.frame.size.height/2-10);
        _priceLab.textColor = [UIColor colorWithRed:233/255.0 green:233/255.0 blue:233/255.0 alpha:1];
        _priceLab.hidden = YES;
    }
    return _priceLab;
}

- (UILabel *)deliveryFeeLab{
    if(!_deliveryFeeLab){
        _deliveryFeeLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 200, 20)];
        _deliveryFeeLab.font = [UIFont systemFontOfSize:13];
        _deliveryFeeLab.text = [NSString stringWithFormat:@"另需配送费 0"];
        _deliveryFeeLab.center = CGPointMake(100+30,self.frame.size.height/2);
        _deliveryFeeLab.textColor = [UIColor colorWithRed:169/255.0 green:169/255.0 blue:169/255.0 alpha:1];
    }
    return _deliveryFeeLab;
}

- (UIButton *)accountButton{
    if(!_accountButton){
        _accountButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _accountButton.hidden = YES;
        _accountButton.frame = CGRectMake(self.frame.size.width-85, 0, 85, self.frame.size.height);
        _accountButton.backgroundColor = [UIColor greenColor];
        _accountButton.titleLabel.font = [UIFont boldSystemFontOfSize:15];
        [_accountButton setTitleColor:CashierDeskBackGroundColor forState:UIControlStateNormal];
        [_accountButton setTitle:@"去结算" forState:UIControlStateNormal];
        [_accountButton addTarget:self action:@selector(checkout) forControlEvents:UIControlEventTouchUpInside];
    }
    return _accountButton;
}

- (UILabel *)deliveryStandardLab{
    if(!_deliveryStandardLab){
        _deliveryStandardLab = [[UILabel alloc]initWithFrame:CGRectMake(self.frame.size.width-110, 0, 110, self.frame.size.height)];
        _deliveryStandardLab.textAlignment = NSTextAlignmentCenter;
        _deliveryStandardLab.font = [UIFont boldSystemFontOfSize:15];
        _deliveryStandardLab.text = [NSString stringWithFormat:@"¥%ld 起送",self.deliveryStandard];
        _deliveryStandardLab.textColor = [UIColor colorWithRed:169/255.0 green:169/255.0 blue:169/255.0 alpha:1];
    }
    return _deliveryStandardLab;
}

- (void)checkout{
    if([self.delegate respondsToSelector:@selector(cashierDeskForCheckOut)]){
        [self.delegate cashierDeskForCheckOut];
    }
}
@end


