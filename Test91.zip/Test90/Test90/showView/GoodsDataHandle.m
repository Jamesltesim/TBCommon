//
//  GoodsDataHandle.m
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "GoodsDataHandle.h"

@interface GoodsDataHandle(){

    NSArray *_titleArray;
    
    NSString *_selectedTitleName;
    
    NSInteger cashierAccount;
}
//订单详情里面按照title不同显示的小红点
@property (nonatomic,strong) NSMutableDictionary *markTitleDictionary;

@property (nonatomic,strong) NSMutableDictionary *contentDictionary;

@end

@implementation GoodsDataHandle

#pragma mark- life cycle
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}


#pragma mark- 公开方法
- (NSArray *)billDetail{
    NSArray *detail = self.contentDictionary.allValues;
    
    NSMutableArray *marr = [[NSMutableArray alloc]initWithCapacity:0];
    
    
    for(NSArray *array in detail){
        for (NSDictionary *dict in array){
            if ([dict[@"amount"] integerValue] > 0){
                [marr addObject:dict];
            }
        }
    }
    NSLog(@"detail:%@",marr);
    return marr;
}
- (void)addGoodAt:(GoodIndexPath *)goodPath{
    NSMutableArray *marray = [self.contentDictionary objectForKey:goodPath.titleKey];
    NSMutableDictionary *mdict = marray[goodPath.row];
    NSNumber *originalNum = [mdict objectForKey:@"amount"];
    
//    设置当前商品的 amount
    [mdict setObject:[NSNumber numberWithInteger:[originalNum integerValue] + 1] forKey:@"amount"];
    NSLog(@"contentDict:%@",_contentDictionary);
    
}

- (void)addGoodAt:(GoodIndexPath *)goodPath result:(void (^)(NSInteger, NSInteger))result{
    [self addGoodAt:goodPath];
    
    //    修改小红点 数量
    NSNumber *number = [self.markTitleDictionary objectForKey:goodPath.titleKey];
    NSInteger num = [number integerValue];
    [self.markTitleDictionary setObject:[NSNumber numberWithInteger:++num] forKey:goodPath.titleKey];
    
    
    //    更新收银台 账单
    NSInteger price = [self updateCashierPriceWtihGoodIndex:goodPath isAdd:YES];
    result(num,price);
}

- (void)subGoodAt:(GoodIndexPath *)goodPath{
    NSMutableArray *marray = [self.contentDictionary objectForKey:goodPath.titleKey];
    NSMutableDictionary *mdict = marray[goodPath.row];
    NSInteger amount = [[mdict objectForKey:@"amount"] integerValue];

    
    //    设置当前商品的 amount
    if(amount == 0){
        return;
    }
    [mdict setObject:[NSNumber numberWithInteger:amount - 1] forKey:@"amount"];
    NSLog(@"contentDict:%@",_contentDictionary);
}
- (void)subGoodAt:(GoodIndexPath *)goodPath result:(void (^)(NSInteger, NSInteger))result{
    //    修改小红点 数量
    NSNumber *number = [self.markTitleDictionary objectForKey:goodPath.titleKey];
    NSInteger num = [number integerValue];
    if(num == 0){
        return ;
    }
    [self.markTitleDictionary setObject:[NSNumber numberWithInteger:--num] forKey:goodPath.titleKey];
    
//    修改商品数据中的 数量
    [self subGoodAt:goodPath];
    
    //    更新收银台 账单
   NSInteger price = [self updateCashierPriceWtihGoodIndex:goodPath isAdd:NO];
    result(num,price);
}



- (NSArray *)getCurrentContentArray{
    if(self.contentDictionary && _selectedTitleName){
        return  [self.contentDictionary objectForKey:_selectedTitleName];
        
    }
    return @[];
}

- (void)resetData{
    _titleArray = nil;
    _contentDictionary = nil;

}

#pragma mark- 内部方法

- (NSInteger)updateCashierPriceWtihGoodIndex:(GoodIndexPath *)goodPath isAdd:(BOOL)flog{
   
    NSMutableArray *marray = [self.contentDictionary objectForKey:goodPath.titleKey];
    NSMutableDictionary *mdict = marray[goodPath.row];
//    NSInteger amount = [[mdict objectForKey:@"amount"] integerValue];
    NSInteger price = [[mdict objectForKey:@"price"] integerValue];
    
    if (flog){
        cashierAccount += price;
    }else{
        cashierAccount -= price;
    }
    return cashierAccount;
}
#pragma mark- set get

- (NSMutableDictionary *)markTitleDictionary{
    if(!_markTitleDictionary){
        _markTitleDictionary = [[NSMutableDictionary alloc]initWithCapacity:0];
    }
    return _markTitleDictionary;
}

- (NSArray *)titleArray{
    if(!_titleArray){
        NSMutableArray *marr = [[NSMutableArray alloc]initWithCapacity:0];
        for (NSArray * array in self.dataArray){
            if(array.count == 1){
                NSDictionary *dict = array[0];
                if(dict.allKeys.count == 1){
                    [marr addObject:dict.allKeys[0]];
                    
//                    初始化小红点 数据，如果不显示，默认为0
                    [self.markTitleDictionary setObject:[NSNumber numberWithInteger:0] forKey:dict.allKeys[0]];
                }
                
            }
          
        }
        _titleArray = marr;
    }
    return _titleArray;
}

// 处理成title content   字典对应的形式
- (NSMutableDictionary *)contentDictionary{
    if(!_contentDictionary){
        _contentDictionary = [[NSMutableDictionary alloc]initWithCapacity:0];
        for (NSArray * array in self.dataArray){
            if(array.count == 1){
                NSDictionary *dict = array[0];
                if([dict isKindOfClass:[NSDictionary class]]){
                    [dict enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
                        if([obj isKindOfClass:[NSArray class]]){
                            NSArray *array = (NSArray *)obj;
                            NSMutableArray *marray = [[NSMutableArray alloc] initWithCapacity:0];
                            for(NSDictionary *dictTmp in array){
                                NSMutableDictionary *mdict = [[NSMutableDictionary alloc] initWithDictionary:dictTmp];
                                [mdict setObject:[NSNumber numberWithInteger:0] forKey:@"amount"];
                                [marray addObject:mdict];
                            }
                             [_contentDictionary setObject:marray forKey:key];
                        }
                        
                       
                       
                    }];
                }
            }
            
        }
        
        NSLog(@"contentDictionary:%@",_contentDictionary);
    }
    return _contentDictionary;
}

- (NSInteger)redDotNumber{
    NSArray *array = self.markTitleDictionary.allValues;
    
    NSInteger result = 0;
    for(NSNumber *temp in array){
        result += [temp integerValue];
    }
    return result;
    
}
@end

            /*   ～～～～～～～～～～～～～～～～～～～～～～～～～～～～～～     */

@interface GoodIndexPath()
@end

@implementation GoodIndexPath
- (instancetype)goodIndexPathForRow:(NSInteger)row withGoodId:(NSString *)goodId inTitleKey:(NSString *)titleKey{
    
    GoodIndexPath *indexPath = [[GoodIndexPath alloc]init];
    indexPath.titleKey = titleKey;
    indexPath.goodId = goodId;
    indexPath.row = row;
    
    return indexPath;
}
@end
