//
//  ShowGoodsView.h
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GoodsDataHandle.h"
#import "GoodTableViewCell.h"

@protocol ShowGoodsViewDelegate;

@interface ShowGoodsView : UIView

@property (nonatomic,assign) id<ShowGoodsViewDelegate> delegate;

@property (nonatomic) CGFloat titleTabViewCellHeight;
@property (nonatomic) CGFloat contentTabViewCellHeight;

- (instancetype)initWithFrame:(CGRect)frame withDataHandle:(GoodsDataHandle *)dataHandle;

- (void)updateDataHandleWtih:(GoodsDataHandle *)dataHandle;
@end

@protocol ShowGoodsViewDelegate<NSObject>

- (void)showGoodsView:(ShowGoodsView *)goodView didSelectItemAtGoodIndexPath:(GoodIndexPath *)goodIndex;

@end

