//
//  GoodTableViewCell.h
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GoodsDataHandle.h"

@protocol GoodTableViewCellDelegate;

@interface GoodTableViewCell : UITableViewCell

@property (nonatomic,assign) id<GoodTableViewCellDelegate>  delegate;

@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UILabel *name;

//月销售
@property (weak, nonatomic) IBOutlet UILabel *mouthSell;

//力推
@property (weak, nonatomic) IBOutlet UILabel *hotSell;


@property (weak, nonatomic) IBOutlet UILabel *price;


@property (nonatomic,strong) GoodIndexPath *goodIndex;

- (void)updateGoodAmount:(NSNumber *)num;

@end


@protocol GoodTableViewCellDelegate<NSObject>
- (void)addGoodTableViewCell:(GoodTableViewCell *)cell AtIndex:(GoodIndexPath *)goodIndex;
- (void)subGoodTableViewCell:(GoodTableViewCell *)cell AtIndex:(GoodIndexPath *)goodIndex;
@end
