//
//  GoodTableViewCell.m
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "GoodTableViewCell.h"

@interface GoodTableViewCell(){
    
}
@property (weak, nonatomic) IBOutlet UIButton *subBtn;
@property (weak, nonatomic) IBOutlet UILabel *amountLab;

@end

@implementation GoodTableViewCell

//reloadData后 重新给cell赋值
- (void)updateGoodAmount:(NSNumber *)num{
    
    NSInteger number = [num integerValue];
    self.goodIndex.amount = number;
    if(self.goodIndex.amount > 0){
        if(self.subBtn.isHidden && self.amountLab.isHidden){
            self.subBtn.hidden = NO;
            self.amountLab.hidden = NO;
        }
        
        self.amountLab.text = [NSString stringWithFormat:@"%ld",self.goodIndex.amount];
    }
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.subBtn.hidden = YES;
    self.amountLab.hidden = YES;
}
- (IBAction)subButton:(id)sender {
    
    if(self.goodIndex.amount == 1 ){
        self.goodIndex.amount--;
        self.subBtn.hidden = YES;
        self.amountLab.hidden = YES;
//        return;
    }else if (self.goodIndex.amount == 0){
        self.subBtn.hidden = YES;
        self.amountLab.hidden = YES;
//        return;
    }
    else{
        self.goodIndex.amount --;
        self.amountLab.text = [NSString stringWithFormat:@"%ld",self.goodIndex.amount];
    }
    
    
    if([self.delegate respondsToSelector:@selector(subGoodTableViewCell: AtIndex:)]){
        [self.delegate subGoodTableViewCell:self AtIndex:self.goodIndex];
    }
}
- (IBAction)addButton:(id)sender {
    self.goodIndex.amount ++;
    self.amountLab.text = [NSString stringWithFormat:@"%ld",self.goodIndex.amount];
    
    if(self.subBtn.isHidden && self.amountLab.isHidden){
        self.subBtn.hidden = NO;
        self.amountLab.hidden = NO;
    }
    
    if([self.delegate respondsToSelector:@selector(addGoodTableViewCell:AtIndex:)]){
        [self.delegate addGoodTableViewCell:self AtIndex:self.goodIndex];
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
