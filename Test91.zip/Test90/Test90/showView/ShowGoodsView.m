//
//  ShowGoodsView.m
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "ShowGoodsView.h"
#import "CashierDeskView.h"
#import "TitleTableViewCell.h"

@interface ShowGoodsView()<UITableViewDelegate,UITableViewDataSource,GoodTableViewCellDelegate,CashierDeskViewDelegate>{
    NSInteger tabWidthZoom ;
    NSInteger cashierHeight;
}
@property (nonatomic,strong) UITableView *titleTabView;
@property (nonatomic,strong) UITableView *contentTabView;


@property (nonatomic,strong) NSArray *titleArray;
@property(nonatomic,strong) NSMutableDictionary *contentDictionary;

//收银台
@property (nonatomic,strong) CashierDeskView *cashierView;


//绑定数据
@property (nonatomic,strong) GoodsDataHandle *dataHandle;

@property (nonatomic,strong) TitleTableViewCell *titleSelectedCell;
@end

@implementation ShowGoodsView

#pragma mark- life cycle

- (instancetype)initWithFrame:(CGRect)frame withDataHandle:(GoodsDataHandle *)dataHandle{
    ShowGoodsView *goodsView = [self initWithFrame:frame];
    goodsView.dataHandle = dataHandle;
    
    return goodsView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        tabWidthZoom = 5;
        cashierHeight = 45;

        
        [self addSubview:self.titleTabView];
        [self addSubview:self.contentTabView];
        //         [self.titleTabView scrollToRowAtIndexPath: atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
        
        //设置table选中第一行
//        [self.titleTabView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionMiddle];
        
        [self addSubview:self.cashierView];
        [self.cashierView showPriceCaption];
    }
    return self;
}

#pragma mark- 公开方法
- (void)updateDataHandleWtih:(GoodsDataHandle *)dataHandle{
    self.dataHandle = dataHandle;
    self.dataHandle.selectedTitleName = dataHandle.titleArray[0];
    [self.titleTabView reloadData];
    [self.contentTabView reloadData];
    
    
    [self.dataHandle billDetail];
    //设置table选中第一行
//     [self.titleTabView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionMiddle];
//    NSLog(@"data:%@",dataHandle.dataArray);
}

#pragma mark- set get

- (CashierDeskView *)cashierView{
    if(!_cashierView){
        _cashierView = [[CashierDeskView alloc]initWithFrame:CGRectMake(0, self.frame.size.height-cashierHeight, self.frame.size.width, cashierHeight)];
        _cashierView.delegate = self;
    }
    return _cashierView;
}

- (NSArray *)titleArray{
    
    if(!_titleArray){
        
        _titleArray =@[];
    }
    return _titleArray;
}

- (NSMutableDictionary *)contentDictionary{
    
    if(!_contentDictionary){
        
        _contentDictionary =[[NSMutableDictionary alloc] initWithCapacity:0];
    }
    return _contentDictionary;
}
- (UITableView *)titleTabView{
    if(!_titleTabView){
        
        _titleTabView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width/tabWidthZoom, self.frame.size.height-cashierHeight) style:UITableViewStylePlain];
        _titleTabView.delegate = self;
        _titleTabView.dataSource = self;
        _titleTabView.separatorStyle = UITableViewCellSeparatorStyleNone;
//        _titleTabView.backgroundColor = [UIColor yellowColor];
        _titleTabView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    return _titleTabView;
}

- (UITableView *)contentTabView{
    if(!_contentTabView){
        
        _contentTabView = [[UITableView alloc]initWithFrame:CGRectMake(self.frame.size.width/tabWidthZoom, 0, self.frame.size.width/tabWidthZoom*(tabWidthZoom-1), self.frame.size.height-cashierHeight) style:UITableViewStylePlain];
        _contentTabView.delegate = self;
        _contentTabView.dataSource = self;
//        _contentTabView.backgroundColor = [UIColor purpleColor];
        _contentTabView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _contentTabView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    return _contentTabView;
}

#pragma mark- tableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([tableView isEqual:self.titleTabView]){
        if(self.titleTabViewCellHeight !=0){
            return self.titleTabViewCellHeight;
        }else{
            return 45;
        }
    }else if ([tableView isEqual:self.contentTabView]){
        if(self.contentTabViewCellHeight !=0){
            return self.contentTabViewCellHeight;
        }else{
            return 45;
        }
    }
  
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if([tableView isEqual:self.titleTabView]){
//        return self.titleArray.count;
        return self.dataHandle.titleArray.count;
    }else if ([tableView isEqual:self.contentTabView]){
        
        NSArray *array = [self.dataHandle getCurrentContentArray];
        return array.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
//    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@""];
    
    
    if([tableView isEqual:self.titleTabView]){
        TitleTableViewCell *titleCell = [[[NSBundle mainBundle] loadNibNamed:@"TitleTableViewCell" owner:nil options:nil]lastObject];
        titleCell.selectionStyle = UITableViewCellSelectionStyleNone;
        if(!self.titleSelectedCell){
            self.titleSelectedCell = titleCell;
            [self.titleSelectedCell selected];
        }
        
        titleCell.textLabel.text = self.dataHandle.titleArray[indexPath.row];
        
        
        return titleCell;
        
    }else if ([tableView isEqual:self.contentTabView]){
        
        GoodTableViewCell *goodCell = [[[NSBundle mainBundle] loadNibNamed:@"GoodTableViewCell" owner:nil options:nil]lastObject];
        goodCell.selectionStyle = UITableViewCellSelectionStyleNone;
        goodCell.delegate = self;
        
        NSArray *contentArray = [self.dataHandle getCurrentContentArray];
        NSDictionary *dict = contentArray[indexPath.row];
        
        
        GoodIndexPath *goodIndex = [[GoodIndexPath alloc]init];
        goodIndex.titleKey  = self.dataHandle.selectedTitleName ;
        goodIndex.goodId    = dict[@"goodid"];
        goodIndex.row       = indexPath.row;
        
        goodCell.goodIndex = goodIndex;
        [goodCell updateGoodAmount:dict[@"amount"]];
        
        goodCell.name.text = dict[@"title"];
        goodCell.price.text = [NSString stringWithFormat:@"%@",dict[@"price"]];
        
        return goodCell;
        
    }
   
    return nil;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([tableView isEqual:self.titleTabView]){
        
        self.dataHandle.selectedTitleName = self.dataHandle.titleArray[indexPath.row];
        [self.contentTabView reloadData];
        
        [self.titleSelectedCell unselectd];
        self.titleSelectedCell = [tableView cellForRowAtIndexPath:indexPath];
        [self.titleSelectedCell selected];
        
    }else if ([tableView isEqual:self.contentTabView]){
        
        if([self.delegate respondsToSelector:@selector(showGoodsView:didSelectItemAtGoodIndexPath:)]){
        
            GoodTableViewCell *cell = (GoodTableViewCell *)[tableView cellForRowAtIndexPath:indexPath];
            [self.delegate showGoodsView:self didSelectItemAtGoodIndexPath:cell.goodIndex];
        }
    }
}

#pragma mark- GoodTableViewCellDelegate

- (void)addGoodTableViewCell:(GoodTableViewCell *)cell AtIndex:(GoodIndexPath *)goodIndex{
    NSLog(@"goodIndex  title:%@  goodid:%@  row:%ld",goodIndex.titleKey,goodIndex.goodId,goodIndex.row);
//    [self.dataHandle addGoodAt:goodIndex];
    
    
    NSInteger index = [self.dataHandle.titleArray indexOfObject:goodIndex.titleKey];
    TitleTableViewCell *titleCell = [self.titleTabView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    __block typeof(self)bself = self;
    [self.dataHandle addGoodAt:goodIndex result:^(NSInteger titleNumber, NSInteger cashierPrice) {
        if(titleNumber > 0){
            [titleCell showRedDot];
            titleCell.redDot.text = [NSString stringWithFormat:@"%ld",titleNumber];
        }else{
            [titleCell hideRedDot];
        }
        [bself.cashierView changeCashierWithMoney:cashierPrice redDot:bself.dataHandle.redDotNumber];
    }];
    
}

- (void)subGoodTableViewCell:(GoodTableViewCell *)cell AtIndex:(GoodIndexPath *)goodIndex{
    NSLog(@"goodIndex  title:%@  goodid:%@  row:%ld",goodIndex.titleKey,goodIndex.goodId,goodIndex.row);
//    [self.dataHandle subGoodAt:goodIndex];
//    NSLog(@"sub:%ld",[self.dataHandle markAmountSubGoodAt:goodIndex]);
    
    NSInteger index = [self.dataHandle.titleArray indexOfObject:goodIndex.titleKey];
    TitleTableViewCell *titleCell = [self.titleTabView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0]];
    
    __block typeof(self)bself = self;
    [self.dataHandle subGoodAt:goodIndex result:^(NSInteger titleNumber, NSInteger cashierPrice) {
        
        if(titleNumber > 0){
            [titleCell showRedDot];
            titleCell.redDot.text = [NSString stringWithFormat:@"%ld",titleNumber];
        }else{
            [titleCell hideRedDot];
        }
        
        [bself.cashierView changeCashierWithMoney:cashierPrice redDot:bself.dataHandle.redDotNumber];
    }];
}

#pragma mark- CashierDeskViewDelegate
- (void)cashierDeskForCheckOut{
    [self.dataHandle billDetail];
}
@end




