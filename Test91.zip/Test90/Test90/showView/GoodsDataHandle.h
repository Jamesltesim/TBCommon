//
//  GoodsDataHandle.h
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <Foundation/Foundation.h>

@class GoodIndexPath;

@interface GoodsDataHandle : NSObject

//配送费
@property (nonatomic) float deliveryFee;

//总费用
@property (nonatomic) float account;

@property (nonatomic) NSInteger redDotNumber;

//数据
@property (nonatomic,strong) NSArray<NSArray<NSDictionary *> *> *dataArray;
@property (nonatomic,strong,readonly) NSArray *titleArray;

//当前选中的title
@property(nonatomic,strong) NSString *selectedTitleName;

- (void)resetData;
//添加商品
- (void)addGoodAt:(GoodIndexPath *)goodPath;
- (void)addGoodAt:(GoodIndexPath *)goodPath result:(void (^)(NSInteger titleNumber,NSInteger cashierPrice))result;
//减少商品
- (void)subGoodAt:(GoodIndexPath *)goodPath;
- (void)subGoodAt:(GoodIndexPath *)goodPath result:(void (^)(NSInteger titleNumber,NSInteger cashierPrice))result;


//获取用户选择的 商品信息
- (NSArray *)billDetail;
- (NSArray *)getCurrentContentArray;


@end


/*          */



@interface GoodIndexPath : NSObject

//类别 （店长推荐，主食，饮品）
@property(nonatomic,strong) NSString *titleKey;
//商品id
@property (nonatomic,strong) NSString *goodId;
//当前类别下 的位置
@property (nonatomic)   NSInteger row;

//选择产品的数量
@property (nonatomic) NSInteger amount;

- (instancetype)goodIndexPathForRow:(NSInteger)row withGoodId:(NSString *)goodId inTitleKey:(NSString *)titleKey;

@end
