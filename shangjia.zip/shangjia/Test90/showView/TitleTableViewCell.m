//
//  TitleTableViewCell.m
//  Test90
//
//  Created by Toby on 2017/11/21.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "TitleTableViewCell.h"

@implementation TitleTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.redDot.layer.cornerRadius= 7;
    self.redDot.layer.masksToBounds = YES;
    self.redDot.hidden = YES;
    
    self.redDot.textAlignment = NSTextAlignmentCenter;
}

- (void)selected{
    self.bgView.backgroundColor = [UIColor whiteColor];
    self.line.hidden = YES;
}

- (void)unselectd{
    self.bgView.backgroundColor = [UIColor colorWithRed:232/255.0 green:232/255.0 blue:232/255.0 alpha:1];
    self.line.hidden = NO;
}

- (void)showRedDot{
    if(self.redDot.isHidden == YES){
        self.redDot.hidden = NO;
    }
    
}

- (void)hideRedDot{
    
    if(self.redDot.isHidden == NO){
        self.redDot.hidden = YES;
    }
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
