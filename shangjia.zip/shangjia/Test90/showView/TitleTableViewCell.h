//
//  TitleTableViewCell.h
//  Test90
//
//  Created by Toby on 2017/11/21.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *bgView;

@property (weak, nonatomic) IBOutlet UIView *line;

@property (weak, nonatomic) IBOutlet UILabel *redDot;
- (void)selected;
- (void)unselectd;

- (void)showRedDot;
- (void)hideRedDot;

@end
