//
//  CashierDeskView.h
//  Test90
//
//  Created by Toby on 2017/11/20.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol CashierDeskViewDelegate;

@interface CashierDeskView : UIView

//起送价格
@property (nonatomic) NSInteger deliveryStandard;

@property (nonatomic,assign) id<CashierDeskViewDelegate> delegate;
// 显示 / 隐藏价格栏
- (void)showPriceCaption;
- (void)hidePriceCaption;

- (void)changeCashierWithMoney:(NSInteger)money redDot:(NSInteger)number;


@end

@protocol CashierDeskViewDelegate<NSObject>
- (void)cashierDeskForCheckOut;
@end
