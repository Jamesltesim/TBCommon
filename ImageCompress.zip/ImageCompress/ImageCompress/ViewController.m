//
//  ViewController.m
//  ImageCompress
//
//  Created by Toby on 2017/11/21.
//  Copyright © 2017年 Verge. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+JKSuperCompress.h"
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UIImageView *image2;

@end

@implementation ViewController


- (float ) folderSizeAtPath:(NSString*) folderPath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:folderPath]) return 0;
    NSEnumerator *childFilesEnumerator = [[manager subpathsAtPath:folderPath] objectEnumerator];
    NSString* fileName;
    long long folderSize = 0;
    while ((fileName = [childFilesEnumerator nextObject]) != nil){
        NSString* fileAbsolutePath = [folderPath stringByAppendingPathComponent:fileName];
        folderSize += [self fileSizeAtPath:fileAbsolutePath];
    }
    return folderSize/(1024.0*1024.0);
}


- (long long) fileSizeAtPath:(NSString*) filePath{
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
  NSString *path =  [[NSBundle mainBundle] pathForResource:@"22" ofType:@"jpg"];
    
    NSLog(@"path:%@",path);
    
    self.image1.image = [UIImage imageNamed:@"22.jpg"];
    
    NSData *data = [UIImage jk_compressImage:[UIImage imageNamed:@"22.jpg"] toMaxLength:300 maxWidth:300];
    self.image2.image = [UIImage imageWithData:data];
   
    
    NSData *data1 =UIImageJPEGRepresentation([UIImage imageNamed:@"22.jpg"],1);
    NSLog(@"原来大小:%fMb   现在大小:%lf kb",[self fileSizeAtPath:path],[data length]/1024.0f);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
