//
//  GoodsDataHandle.h
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <Foundation/Foundation.h>

@class GoodIndexPath;

@interface GoodsDataHandle : NSObject

//配送费
@property (nonatomic) float deliveryFee;

//总费用
@property (nonatomic) float account;

@property (nonatomic,strong) NSMutableArray<NSMutableDictionary *> *dataArray;

//添加商品
- (void)addGoodAt:(GoodIndexPath *)GoodPath;
//减少商品
- (void)subGoodAt:(GoodIndexPath *)GoodPath;
@end


/*          */



@interface GoodIndexPath : NSObject

//类别 （店长推荐，主食，饮品）
@property(nonatomic,strong) NSString *titleKey;
//商品id
@property (nonatomic,strong) NSString *goodId;
//当前类别下 的位置
@property (nonatomic)   NSInteger row;

- (instancetype)goodIndexPathForRow:(NSInteger)row withGoodId:(NSString *)goodId inTitleKey:(NSString *)titleKey;

@end
