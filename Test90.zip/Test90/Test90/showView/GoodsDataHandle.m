//
//  GoodsDataHandle.m
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "GoodsDataHandle.h"

@interface GoodsDataHandle(){
    NSMutableArray<NSMutableDictionary *> * _dataArray;
}

@end

@implementation GoodsDataHandle

#pragma mark- life cycle
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}


#pragma mark- 公开方法

- (void)addGoodAt:(GoodIndexPath *)GoodPath{
    
}

- (void)subGoodAt:(GoodIndexPath *)GoodPath{
    
}

#pragma mark- set get
- (NSMutableArray<NSMutableDictionary *> *)dataArray{
    if(!_dataArray){
        _dataArray = [[NSMutableArray alloc]initWithCapacity:0];
    }
    return _dataArray;
}
- (void)setDataArray:(NSMutableArray<NSMutableDictionary *> *)dataArray{
    if(dataArray){
        for (NSMutableDictionary *mdict in dataArray){
            //数量默认为0
            [mdict setObject:[NSNumber numberWithInt:0] forKey:@"amount"];
        }
    }
}


@end

@interface GoodIndexPath()
@end

@implementation GoodIndexPath
- (instancetype)goodIndexPathForRow:(NSInteger)row withGoodId:(NSString *)goodId inTitleKey:(NSString *)titleKey{
    
    GoodIndexPath *indexPath = [[GoodIndexPath alloc]init];
    indexPath.titleKey = titleKey;
    indexPath.goodId = goodId;
    indexPath.row = row;
    
    return indexPath;
}
@end
