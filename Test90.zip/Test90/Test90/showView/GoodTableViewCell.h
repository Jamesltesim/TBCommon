//
//  GoodTableViewCell.h
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GoodTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgView;

@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *mouthSell;
@property (weak, nonatomic) IBOutlet UILabel *hotSell;
@property (weak, nonatomic) IBOutlet UILabel *price;
@end
