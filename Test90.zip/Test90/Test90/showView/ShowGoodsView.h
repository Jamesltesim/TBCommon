//
//  ShowGoodsView.h
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GoodsDataHandle.h"
#import "GoodTableViewCell.h"
@interface ShowGoodsView : UIView

@property (nonatomic) CGFloat titleTabViewCellHeight;
@property (nonatomic) CGFloat contentTabViewCellHeight;

- (instancetype)initWithFrame:(CGRect)frame withDataHandle:(GoodsDataHandle *)dataHandle;

@end

@interface CashierDeskView :UIView
@end
