//
//  ShowGoodsView.m
//  Test90
//
//  Created by xian on 2017/11/14.
//  Copyright © 2017年 xian. All rights reserved.
//

#import "ShowGoodsView.h"


@interface ShowGoodsView()<UITableViewDelegate,UITableViewDataSource>{
    NSInteger tabWidthZoom ;
    NSInteger cashierHeight;
}
@property (nonatomic,strong) UITableView *titleTabView;
@property (nonatomic,strong) UITableView *contentTabView;


@property (nonatomic,strong) NSString *titleKey;

@property (nonatomic,strong) NSArray *titleArray;
//@property (nonatomic,strong) NSArray *contentArray;
@property(nonatomic,strong) NSMutableDictionary *contentDictionary;


@property (nonatomic,strong) CashierDeskView *cashierView;

@property (nonatomic,strong) GoodsDataHandle *dataHandle;

@end

@implementation ShowGoodsView

#pragma mark- life cycle

- (instancetype)initWithFrame:(CGRect)frame withDataHandle:(GoodsDataHandle *)dataHandle{
    ShowGoodsView *goodsView = [self initWithFrame:frame];
    goodsView.dataHandle = dataHandle;
    
    return goodsView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        tabWidthZoom = 5;
        cashierHeight = 45;
        self.titleKey = @"A";
        self.titleArray = @[@"A",@"B",@"C",@"D"];
        self.contentDictionary = [[NSMutableDictionary alloc] initWithDictionary:@{@"A":@[@"a1",@"a2",@"a3",@"a4"],
                                                                                   @"B":@[@"b1",@"b2",@"b3",@"b4"],
                                                                                   @"C":@[@"c1",@"c2",@"c3",@"c4"],
                                                                                   @"D":@[@"d1",@"d2",@"d3",@"d4"]
                                                                                   }];
        
        [self addSubview:self.titleTabView];
        [self addSubview:self.contentTabView];
        //         [self.titleTabView scrollToRowAtIndexPath: atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
        [self.titleTabView selectRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:NO scrollPosition:UITableViewScrollPositionMiddle];
        
        [self addSubview:self.cashierView];
    }
    return self;
}

#pragma mark- set get

- (CashierDeskView *)cashierView{
    if(!_cashierView){
        _cashierView = [[CashierDeskView alloc]initWithFrame:CGRectMake(0, self.frame.size.height-cashierHeight, self.frame.size.width, cashierHeight)];
    }
    return _cashierView;
}

- (NSArray *)titleArray{
    
    if(!_titleArray){
        
        _titleArray =@[];
    }
    return _titleArray;
}

- (NSMutableDictionary *)contentDictionary{
    
    if(!_contentDictionary){
        
        _contentDictionary =[[NSMutableDictionary alloc] initWithCapacity:0];
    }
    return _contentDictionary;
}
- (UITableView *)titleTabView{
    if(!_titleTabView){
        
        _titleTabView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width/tabWidthZoom, self.frame.size.height-cashierHeight) style:UITableViewStylePlain];
        _titleTabView.delegate = self;
        _titleTabView.dataSource = self;
        _titleTabView.separatorStyle = UITableViewCellSeparatorStyleNone;
//        _titleTabView.backgroundColor = [UIColor yellowColor];
        _titleTabView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    return _titleTabView;
}

- (UITableView *)contentTabView{
    if(!_contentTabView){
        
        _contentTabView = [[UITableView alloc]initWithFrame:CGRectMake(self.frame.size.width/tabWidthZoom, 0, self.frame.size.width/tabWidthZoom*(tabWidthZoom-1), self.frame.size.height-cashierHeight) style:UITableViewStylePlain];
        _contentTabView.delegate = self;
        _contentTabView.dataSource = self;
//        _contentTabView.backgroundColor = [UIColor purpleColor];
        _contentTabView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _contentTabView.tableFooterView = [[UIView alloc]initWithFrame:CGRectZero];
    }
    return _contentTabView;
}

#pragma mark- tableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if([tableView isEqual:self.titleTabView]){
        if(self.titleTabViewCellHeight !=0){
            return self.titleTabViewCellHeight;
        }else{
            return 45;
        }
    }else if ([tableView isEqual:self.contentTabView]){
        if(self.contentTabViewCellHeight !=0){
            return self.contentTabViewCellHeight;
        }else{
            return 45;
        }
    }
  
    return 0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    if([tableView isEqual:self.titleTabView]){
        return self.titleArray.count;
    }else if ([tableView isEqual:self.contentTabView]){
        
        NSArray *contentArray = [self.contentDictionary objectForKey:self.titleKey];
        if(contentArray.count > 0){
            return contentArray.count;
        }
        return 0;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@""];
    
    
    if([tableView isEqual:self.titleTabView]){
        
        cell.textLabel.text = self.titleArray[indexPath.row];
    }else if ([tableView isEqual:self.contentTabView]){
        
        GoodTableViewCell *goodCell = [[[NSBundle mainBundle] loadNibNamed:@"GoodTableViewCell" owner:nil options:nil]lastObject];
        
        NSArray *contentArray = [self.contentDictionary objectForKey:self.titleKey];
        goodCell.name.text = contentArray[indexPath.row];
        cell = goodCell;
    }
   
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([tableView isEqual:self.titleTabView]){
        self.titleKey = self.titleArray[indexPath.row];
        [self.contentTabView reloadData];
    }
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
@end



@implementation CashierDeskView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:48/255.0 green:48/255.0 blue:48/255.0 alpha:0.8];
    }
    return self;
}
@end
