//
//  ViewController.m
//  1127
//
//  Created by Toby on 2017/11/27.
//  Copyright © 2017年 Verge. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (nonatomic,strong) UITextView *deliveryTextView;
@property (nonatomic,strong) UITextView *addressTextView;
@property (nonatomic,strong) UITextView *businessTimeTextView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //起送条件
    UILabel *promptLab = [[UILabel alloc]initWithFrame:CGRectMake(10, 30, 100, 30)];
    promptLab.text = @"起送条件:";
    promptLab.textColor = [UIColor colorWithRed:81/255.0 green:81/255.0 blue:81/255.0 alpha:1];
    promptLab.font = [UIFont systemFontOfSize:15];
    
    [self.view addSubview:promptLab];
    
    _deliveryTextView = [[UITextView alloc]initWithFrame:CGRectMake(promptLab.frame.origin.x, promptLab.frame.origin.y+promptLab.frame.size.height+10, self.view.frame.size.width-promptLab.frame.origin.x*2, 45)];
    _deliveryTextView.layer.borderWidth = 0.5;
    _deliveryTextView.layer.borderColor = [UIColor colorWithRed:181/255.0 green:181/255.0 blue:181/255.0 alpha:1].CGColor;
    
    [self.view addSubview:_deliveryTextView];
    
    
    //店家地址
    UILabel *promptLab1 = [[UILabel alloc]initWithFrame:CGRectMake(10, _deliveryTextView.frame.origin.y+_deliveryTextView.frame.size.height+20, 100, 30)];
    promptLab1.text = @"店家地址:";
    promptLab1.textColor = [UIColor colorWithRed:81/255.0 green:81/255.0 blue:81/255.0 alpha:1];
    promptLab1.font = [UIFont systemFontOfSize:15];
    
    [self.view addSubview:promptLab1];
    
    _addressTextView = [[UITextView alloc]initWithFrame:CGRectMake(promptLab1.frame.origin.x, promptLab1.frame.origin.y+promptLab1.frame.size.height+10, self.view.frame.size.width-promptLab1.frame.origin.x*2, 45)];
    _addressTextView.layer.borderWidth = 0.5;
    _addressTextView.layer.borderColor = [UIColor colorWithRed:181/255.0 green:181/255.0 blue:181/255.0 alpha:1].CGColor;
    
    [self.view addSubview:_addressTextView];
    
    
    //营业时间
    UILabel *promptLab3 = [[UILabel alloc]initWithFrame:CGRectMake(10, _addressTextView.frame.origin.y+_addressTextView.frame.size.height+20, 300, 30)];
    promptLab3.text = @"营业时间:(格式参照：8:00 ～ 22:00)";
    promptLab3.textColor = [UIColor colorWithRed:81/255.0 green:81/255.0 blue:81/255.0 alpha:1];
    promptLab3.font = [UIFont systemFontOfSize:15];
    
    [self.view addSubview:promptLab3];
    
    _businessTimeTextView = [[UITextView alloc]initWithFrame:CGRectMake(promptLab3.frame.origin.x, promptLab3.frame.origin.y+promptLab3.frame.size.height+10, self.view.frame.size.width-promptLab3.frame.origin.x*2, 45)];
    _businessTimeTextView.text = @"8:00 ~ 22:00";
    _businessTimeTextView.layer.borderWidth = 0.5;
    _businessTimeTextView.layer.borderColor = [UIColor colorWithRed:181/255.0 green:181/255.0 blue:181/255.0 alpha:1].CGColor;
    
    [self.view addSubview:_businessTimeTextView];
    
    
    UIButton *confirm = [UIButton buttonWithType:UIButtonTypeCustom];
    confirm.frame = CGRectMake(0, self.view.frame.size.height-50, self.view.frame.size.width, 50);
    [confirm setTitle:@"确定" forState:UIControlStateNormal];
    [confirm addTarget:self action:@selector(confirm:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:confirm];
    
}

- (void)confirm:(UIButton *)sender {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
