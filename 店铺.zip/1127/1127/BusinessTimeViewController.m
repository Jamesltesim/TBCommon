//
//  BusinessTimeViewController.m
//  1127
//
//  Created by Toby on 2017/12/12.
//  Copyright © 2017年 Verge. All rights reserved.
//

#import "BusinessTimeViewController.h"

@interface BusinessTimeViewController ()

@end

@implementation BusinessTimeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
